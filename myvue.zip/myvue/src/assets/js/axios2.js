import {
    request
} from './axios1'


// 首页请求

export function getHomeMultidata(payload) {
    return request({
       params: {
            payload
       },
        method: "get"
    })
};