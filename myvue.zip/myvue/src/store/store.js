import vue from 'vue'
import vuex from 'vuex'

vue.use(vuex)

const state={
  shopName:'点击选择店铺',
  userImgUrl:"../../static/img/userImg.jpg",
  // 存储token
  Authorization: localStorage.getItem('Authorization') ? localStorage.getItem('Authorization') : ''
}
const getters={

};
const actions={
  increase(ctx,n){
    ctx.commit('increase',n)
  }
};
const mutations = {
  chooseShop(state, n) {
    state.shopName = n
  },
  // 修改token，并将token存入localStorage
  changeLogin (state, user) {
    state.Authorization = user.Authorization
    localStorage.setItem('Authorization', user.Authorization);
  }
}

export default new vuex.Store({
  state,
  mutations,
  actions,
  getters
})
