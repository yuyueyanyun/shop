import Vue from 'vue'
import Router from 'vue-router'
import distribution from '@/components/distribution/distribution'
import failure from '@/components/distribution/failure'
import ing from '@/components/distribution/ing'
import soon from '@/components/distribution/soon'
import success from '@/components/distribution/success'

import regist from '@/components/regist'
import checkShopPage from '@/components/checkShopPage'
import apply from '@/components/apply'
import applyDetail from '@/components/applyDetail'
import userNote from '@/components/userNote'
import userCenter from '@/components/userCenter'
import registInfor from '@/components/registInfor'

import delivery from '@/components/PeiSong/delivery'
import person from '@/components/PeiSong/person'
import record from '@/components/PeiSong/record'
import getOrder from '@/components/PeiSong/getOrder'
import sendOrder from '@/components/PeiSong/sendOrder'
import signY from '@/components/PeiSong/signY'
import signN from '@/components/PeiSong/signN'
import getOrderDetails from '@/components/PeiSong/getOrderDetails'
import changePwd from '@/components/PeiSong/changePwd'
import news from '@/components/PeiSong/news'
import newsDetails from '@/components/PeiSong/newsDetails'

Vue.use(Router)

const indexPage = () => import('@/components/indexPage')

const loginU = () => import('@/components/user/loginU')
const parti = () => import('@/components/distribution/parti')
const userAddr = () => import('@/components/userAddr/userAddr')
const newAddr = () => import('@/components/userAddr/newAddr')
const altAddr = () => import('@/components/userAddr/altAddr')
const forget = () => import('@/components/user/forget')

const router = new Router({
  routes: [
    {
      path: '/regist',
      name: 'regist',
      component: regist
    },
    {
      path: '/checkShop',
      name: 'checkShopPage',
      component: checkShopPage
    },
    {
      path: '/myApply',
      name: 'apply',
      component: apply
    },
    {
      path: '/indexPage',
      name: 'indexPage',
      component: indexPage
    },
    {
      path: '/applyDetail',
      name: 'applyDetail',
      component: applyDetail
    },
    {
      path: '/userNote',
      name: 'userNote',
      component: userNote
    },
    {
      path: '/userCenter',
      name: 'userCenter',
      component: userCenter
    },
    {
      path: '/registInfor',
      name: 'registInfor',
      component: registInfor
    },
    {
      path: '/',
      name: 'loginU',
      component: loginU
    },
    {
      path: '/forget',
      name: 'forget',
      component: forget
    },
    {
      path: '/userAddr',
      name: 'userAddr',
      component: userAddr
    },
    {
      path: '/newAddr',
      name: 'newAddr',
      component: newAddr
    },
    {
      path: '/altAddr',
      name: 'altAddr',
      component: altAddr
    },
    {
      path: '/distribution',
      name: 'distribution',
      component: distribution,
      // 以“/”开头的嵌套路径会被当作根路径，所以子路由上不用加“/”;在生成路由时，主路由上的path会被自动添加到子路由之前，所以子路由上的path不用在重新声明主路由上的path了。
      children: [
        {
          path: 'failure',
          name: 'failure',
          component: failure
        },
        {
          path: 'ing',
          name: 'ing',
          component: ing
        },
        {
          path: 'soon',
          name: 'soon',
          component: soon
        },
        {
          path: 'success',
          name: 'success',
          component: success
        }
      ]
    },
    {
      path: '/parti',
      name: 'parti',
      component: parti
    },
    // 冯浪
    {
      path: '/delivery',
      component: delivery
    },
    {
      path: '/person',
      component: person
    },
    {
      path: '/record',
      component: record,
      children: [
        {
          path: 'getOrder',
          component: getOrder
        },
        {
          path: 'sendOrder',
          component: sendOrder
        },
        {
          path: 'signY',
          component: signY
        },
        {
          path: 'signN',
          component: signN
        }
      ]
    },
    {
      path: '/getOrder/getOrderDetails',
      component: getOrderDetails
    },
    {
      path: '/person/changePwd',
      component: changePwd
    },
    {
      path: '/news',
      component: news
    },
    {
      path: '/news/newsDetails',
      component: newsDetails
    }
  ]
})

// 导航守卫
// 使用 router.beforeEach 注册一个全局前置守卫，判断用户是否登陆
router.beforeEach((to, from, next) => {
  if (to.path === '/loginU') {
    next()
  } else {
    let token = localStorage.getItem('Authorization')

    if (token === 'null' || token === '') {
      next('/loginU')
    } else {
      next()
    }
  }
})

export default router
