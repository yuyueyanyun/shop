<template>
  <div class="addDet">
    <div>{{userMes.address}}</div>
    <!--<div>当前距离</div>-->
    <div>{{userMes.receiver}}</div>
    <div>电话：{{userMes.tel1}}</div>
    <div>备用电话:{{userMes.tel2}}</div>
  </div>


</template>

<script>
  export default {
    name: "addreeMes",
    props: ["userMes"],
    created(){

    }
  }
</script>

<style scoped>
  .addDet {
    font-size: 13px;
  }
</style>
