<template>
  <div>
    <header1 titleText="注册" rightShow="0" leftShow="1"/>
    <div class="userKnow">
      <p>用户协议</p>
     {{userDeal}}
    </div>
    <div class="second paddingBox">
      <Checkbox v-model="single">同意用户协议</Checkbox>
    </div>
    <div class="second widthBox">
      <mt-field class="inputBorder" :state="phoneState" label="手机号" placeholder="请输入手机号"
                type="tel" v-model="phone" @input="checkPhone"></mt-field>
    </div>
    <div class="second widthBox">
      <mt-field class="inputBorder" ref="captcha" label="验证码" placeholder=""
                type="text" v-model="captch"></mt-field>
      <mt-button class="sendCaptcha" :disabled="checkNo" type="primary" @click="sendCaptcha">发送验证码</mt-button>
      <div class="prompt" style="display: none" ref="capPrompt">*发送验证码成功，{{restTime}}s后可以再次发送</div>
    </div>
    <div class='nextBtn'>
      <mt-button class="registSum" type="primary" @click="nextStep">下一步</mt-button>
    </div>
  </div>
</template>

<script>
  import {Toast} from "mint-ui";
  import header1 from './header1';

  export default {
    name: "regist",
    data() {
      return {
        toastInstanse: null,
        checkNo: true,
        phone: "",
        captch: "",
        single:false,
        phoneState: "",
        passwordCheckState: '',
        send: false,
        restTime: 60,
        captchCode: "123456",
        userDeal: ''
      }
    },
    methods: {
      checkPhone() {
        var phone = this.$data.phone;
        document.getElementsByClassName("mint-cell-value")[0].getElementsByTagName('input')[0].setAttribute("maxlength", "11");
        if (!(/^1(3|4|5|6|7|8|9)\d{9}$/.test(phone))) {
          this.$data.send = false;
          this.$data.phoneState = "error";
        } else {
          this.$data.send = true;
          this.$data.phoneState = "success";
        }
        if (this.$data.phoneState == "error") {
          this.$data.checkNo = true;
        } else if (this.$data.phoneState == "success" && this.$data.restTime == '60') {
          this.$data.checkNo = false;
        }
      },
      sendCaptcha() {
        this.$axios.get("/littleu/user/register", {
          params: {
            "phone": this.$data.phone
          }
        }).then((resp) => {
          this.$data.captchCode = resp.data;
        });
        this.$refs.capPrompt.style = 'display:block';
        var that = this;
        this.$data.checkNo = true;
        var time = setInterval(function () {
          that.$data.restTime--;
          if (that.$data.restTime == 0) {
            clearInterval(time);
            that.$data.checkNo = false;
            that.$refs.capPrompt.style = 'display:none';
            that.$data.restTime = 60;
          }
        }, 1000);
      },
      nextStep(){
        if(this.single==true){
          if(this.captch==this.captchCode&&this.phoneState=="success"){
            this.$router.push({path:'/registInfor',query:{phone:this.$data.phone}})
          }else {
            this.$data.toastInstanse = Toast({
              message: '验证码有误',
              position: 'middle',
              duration: 3000
            });
          }
        }else {
          this.$data.toastInstanse = Toast({
            message: '请先同意用户协议',
            position: 'middle',
            duration: 3000
          });
        }
      }
    },
    components: {
      header1: header1
    },
    mounted() {
      this.$refs.captcha.$el.style = "width:65%";
      // this.$refs.dateBox.getElementsByTagName("input")[0].setAttribute('class','disType');
    },
    created() {
      var s = '1950-01-01 00:00:00';
      s = s.replace(/-/g, "/");
      var date = new Date(s);
      this.$data.starDate = date;
      var endDate = new Date();
      this.$data.endDate = endDate;
      this.$axios.get('littleu/user/userKnown').then((resp) => {
      this.userDeal=resp.data;
    });
    }
  }
</script>

<style scoped>
*{
  text-align: left
}
  .inputBorder {
    border: 1px #c3c3c3 solid;
    border-radius: 4px;
  }

  .sendCaptcha {
    font-size: 12px;
  }

  .second {
    margin-top: 4%;
  }

  .prompt {
    font-size: 12px;
    color: grey;
  }

  .sendCaptcha {
    position: absolute;
    right: 5%;
    top: 79%;
    height: 48px;
  }

  .registSum {
    margin-top: 3%;
    width: 90%;
    margin-left: 5%;
    text-align: center;
  }

  .userKnow{
    width: 90%;
    height: 360px;
    margin-left: 5%;
    margin-top: 3%;
    border: 1px #e2e2e2 solid;
    padding: 2%;
    overflow-y: scroll
  }
  .paddingBox{
    padding-left: 5%;
  }
  .widthBox{
    width: 90%;
    margin-left: 5%;
  }
.nextBtn>>>label{
  widows: 100%;
  text-align: center;
}

</style>
