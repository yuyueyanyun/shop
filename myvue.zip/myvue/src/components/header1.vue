<template>
  <div class="indexHeader">
    <mt-header class="header1" fixed :title="titleText">
      <mt-button slot="left" v-if="leftShow==1">
        <span>
          <mt-button @click="goBack" icon="back"><span class="font0">返回</span></mt-button>
        </span>
      </mt-button>
      <mt-button slot="right" v-if="rightShow==1">
        <router-link to='/userCenter'  tag='div' class="userHeader">
          <img  class="userHeaderImg"  :src="$store.state.userImgUrl">
        </router-link>
      </mt-button>
      <mt-button slot="right" v-if="rightShow==2">
        <router-link to="userNote" tag="div">
          <Icon class="noteIcon" type="ios-chatboxes" size="24"/>
        </router-link>
      </mt-button>
    </mt-header>
  </div>
</template>

<script>
  export default {
    name: "header1",
    props: ['titleText', 'rightShow', 'leftShow'],
    methods: {
      goBack() {
        console.log(this.$router.go(-1));
      }
    }
  }
</script>

<style scoped>
  .indexHeader {
    height: 40px;
  }

  .userHeader {
    width: 30px;
    height: 30px;
    border-radius: 30px;

    margin-top: 1px;
    margin-right: 3px;
    overflow: hidden;
  }
  .userHeaderImg{
    width: 30px;
    height: 30px;
  }
  .header1 {
    padding: 2px !important;
  }

  .noteIcon {
    margin-right: 10px;
  }
  .font0{
    line-height: 30px;
  }
</style>
