<template>
  <div>
    <header1 titleText="配送信息"  rightShow="1" leftShow="1"/>
    <div>
      <Collapse v-model="value1">
        <Panel name="1">
          配送消息
          <span class="mesTime">时间;2019-12-26</span>
          <p slot="content">尊敬的客户，您的订单145789asd4成功签收，签收情况：本人签收,签收时间2019-12-26 14：53:54,如有疑问请致电客服</p>
        </Panel>
        <Panel name="2">
          配送消息     <span class="mesTime">时间;2019-12-26</span>
          <p slot="content">尊敬的客户，您的订单145789asd4成功签收，签收情况：本人签收,签收时间2019-12-26 14：53:54,如有疑问请致电客服</p>
        </Panel>
        <Panel name="3">
          配送消息     <span class="mesTime">时间;2019-12-26</span>
          <p slot="content">尊敬的客户，您的订单145789asd4成功签收，签收情况：本人签收,签收时间2019-12-26 14：53:54,如有疑问请致电客服</p>
        </Panel>
      </Collapse>
    </div>
  </div>
</template>

<script>
  import header1 from "./header1"

  export default {
    name: "userMessage",
    data(){
      return {
        value1:""
      }
    },
    methods:{

    },
    components: {
      header1: header1
    }
  }
</script>

<style scoped>
* {
  text-align: left;
}
.mesTime{
  float: right;
  margin-right: 2%;
}

</style>
