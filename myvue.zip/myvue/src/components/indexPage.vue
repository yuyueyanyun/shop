<template>
  <div>
    <header1 titleText="首页"  rightShow="1" leftShow="0"/>
    <checkShop/>
    <checkAddress/>
  </div>
</template>

<script>
    import header1 from './header1';
    import checkShop from './checkShop';
    import checkAddress from './checkAddress';
    import submitBtn from './submitBtn';
    export default {
      name: "indexPage",
      components:{
        header1:header1,
        checkShop:checkShop,
        checkAddress:checkAddress,
        submitBtn:submitBtn
      },
      created(){
        if(this.$route.query.shop==null){
          this.$store.commit('chooseShop',"请选择店铺");
        }else if(this.$route.query.shop==1){

        }else {
          this.$store.commit('chooseShop',this.$route.query.shop);
        }
      }
    }
</script>

<style scoped>
*{
  text-align: left
}
</style>
