<template>
  <div>
    <router-link to='/userAddr' tag="div" class="checkAddress">
      <div class="address1 hStyle1" v-if="havDate==1">
        <div class="addressFont lhStyle1">
         <Icon type="md-pin" />
        </div>
        <div class="addressDet">
          <div class="addDet">
            <div>{{userAddressMes.address}}</div>
            <div class="user">{{userAddressMes.receiver}}</div>
            <div>电话：{{userAddressMes.tel1}}</div>
            <div>备用电话:{{userAddressMes.tel2}}</div>
          </div>
        </div>
        <div class="addressFont lhStyle1">
       <Icon type="ios-arrow-forward" />
        </div>
      </div>
      <div class="address1 hStyle2" v-else="havDate==0">
        <div class="addressFont lhStyle2">
         <Icon type="md-pin" />
        </div>
        <div class="addressDet">
          <span>请选择地址</span>
        </div>
        <div class="lhStyle2">
          <Icon type="ios-arrow-forward" />
        </div>
      </div>
      <div class="addressText">
        <span><Icon type="ios-clock" /></span><span>生鲜视频超过3km不配送！</span>
      </div>
    </router-link>
    <mt-button  class="submitBtn" type="primary" @click="sumOrder">提交</mt-button>
  </div>

</template>

<script>
  import addressMes from './addreeMes';
    import {Toast} from "mint-ui";

  export default {
    name: "checkAddress",
    data() {
      return {
        havDate: 0,
        userAddressMes: {},
        toastInstanse: null
      }
    },
    methods: {
      sumOrder(){
        if(this.havDate==0||this.$store.state.shopName=="请选择店铺"){
           this.$data.toastInstanse = Toast({
            message: '请先填写信息',
            position: 'middle',
            duration: 3000
          });
        }else{
      
          var orderId=new Date().getTime()+String(parseInt(Math.random())*100);
           this.$axios.put("/littleu/user/data",{
            siteName:this.$store.state.shopName,
            address:this.$data.userAddressMes.address,
            receiver:this.$data.userAddressMes.receiver,
            orderId: orderId,
            addressId:this.userAddressMes.addressId 
        }).then((resp)=>{
          console.log(resp.data);
          if(resp.data==true){
            this.$data.toastInstanse = Toast({
            message: '提交成功，即将跳转到其他页面',
            position: 'middle',
            duration: 1000
          });
            setTimeout(() => {
              this.$router.push({path:"/applyDetail", query:{orderId:orderId}});
            }, 1000);
              
          }else{
            this.$data.toastInstanse = Toast({
            message: '提交失败，请重新尝试',
            position: 'middle',
            duration: 3000
          });
          }
        })
        }
       
      }
    },
    components: {
      addressMes: addressMes
    },
    created() {
      this.$axios.post("/littleu/user/homePage")
        .then((resp) => {
          console.log(resp.data);
          if(resp.data==""){
            this.$data.havDate=0;
            console.log(this.$data.havDate);
          }else {
            this.$data.havDate=1;
            this.$data.userAddressMes=resp.data;
          }
        });
     console.log(this.$store.state.shopName);
    }
  }
</script>

<style scoped>
  .checkAddress {
    margin-top: 10px;
    width: 96%;
    margin-left: 2%;
    border: 1px black solid;
    border-radius: 2px;
    padding-bottom: 1%;
  }

  .address1 {
    border-bottom: 1px black solid;
    width: 86%;
    margin-left: 5%;
    padding: 2%;
    padding-top: 6%;

  }

  .address1 > div {
    float: left;

  }

  .addressFont {
    width: 5%;
  }

  .addressDet {
    width: 85%;
    margin-left: 4%;
  }

  .addressText {
    padding: 3%;
    line-height: 20px;
    height: 40px;
  }

  .addressText > span {
    margin-left: 4%;
  }

  .addDet {
    font-size: 13px;
  }

  .submitBtn {
    width: 90%;
    position: absolute;
    left: 5%;
    bottom: 10px;
  }

  .lhStyle1{
    line-height: 76px;
  }
  .hStyle1{
    height: 104px;
  }
  .lhStyle2{
    line-height: 20px;
  }
  .hStyle2{
    height: 50px;
  }
  .user{
    margin-left:0px;
  }
</style>
