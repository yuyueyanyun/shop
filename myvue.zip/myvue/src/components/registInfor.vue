<template>
  <div>
    <header1 titleText="详细信息" rightShow="0" leftShow="0"/>
    <div class="second">
      <mt-field class="inputBorder" label="用户昵称" placeholder="请输入用户昵称"
                type="text" v-model="userName"></mt-field>
    </div>
    <div class="second">
      <mt-field class="inputBorder" :state="passwordState" label="密码" placeholder="请输入密码"
                type="password" v-model="password" @input="checkPassword"></mt-field>
      <div class="prompt">*密码为6-16位，且需要包含字母和数字</div>
    </div>
    <div class="second">
      <mt-field class="inputBorder" :state="passwordCheckState" label="确认密码" placeholder="请再次输入密码"
                type="password" v-model="passwordCheck" @input="reCheck"></mt-field>
      <div class="prompt1">{{checkText}}</div>
    </div>
    <div class="second">
      <mt-field class="inputBorder" label="备用电话" placeholder="请输入备用电话"
                type="text" v-model="secPhone"></mt-field>
    </div>
    <div class="second dateBox" @click="dateCheck">
      <mt-field class="inputBorder" label="生日" placeholder="点击选择日期" :disabled="true"
                type="text" v-model="birthdayDate"></mt-field>
    </div>
    <div class="second sexCheck">
      <label class="sexLable">性别</label>
      <Select v-model="sex" class="sexSelect">
        <Option value="男">男</Option>
        <Option value="女">女</Option>
      </Select>

    </div>
    <div>
      <mt-button class="registSum" type="primary" @click="registSub">提交</mt-button>
    </div>
    <mt-datetime-picker
      ref="picker"
      v-model="birthday"
      type="date"
      :start-date="starDate"
      :end-date="endDate"
      @confirm="dateInput"
    >
    </mt-datetime-picker>
  </div>
</template>

<script>
  import {Toast} from "mint-ui";
  import header1 from './header1';
  export default {
    name: "registInfor",
    data() {
      return {
        toastInstanse: null,
        checkNo: true,
        phone: this.$route.query.phone,
        password: "",
        userName: "",
        birthday: '',
        secPhone: "",
        passwordCheck: '',
        checkText: "",
        passwordState: "",
        passwordCheckState: '',
        starDate: "",
        endDate: '',
        birthdayDate: '',
        sex: '',
      }
    },
    methods: {
      checkPassword() {
        var reg = /^(?!([a-zA-Z]+|\d+)$)[a-zA-Z\d]{6,17}$/;
        if (reg.test(this.$data.password)) {
          this.$data.passwordState = "success";
        } else {
          this.$data.passwordState = "error";
        }
      },
      reCheck() {
        if (this.$data.passwordCheck == this.$data.password) {
          this.$data.passwordCheckState = "success";
          this.$data.checkText = "";
        } else {
          this.$data.passwordCheckState = "error";
          this.$data.checkText = "两次输入密码不一致";
        }

      },
      dateCheck() {
        this.$refs.picker.open();
      },
      dateInput(v) {
        this.$data.birthday = v;
        this.$data.birthdayDate = v.getFullYear() + "-" + (v.getMonth() + 1) + '-' + v.getDate();
      },
      registSub() {
        if(this.passwordState=="success"&&this.passwordCheckState=="success"){
          if(this.username!=''&&this.birthday!=''&&this.sex!=""&&this.secPhone!=''){
            var registerInfor = {
              useraccount: this.$data.phone,
              username: this.$data.userName,
              userpassword: this.$data.password,
              userpic: '../../static/img/userImg.jpg',
              usersex: this.$data.sex,
              userage: "24",
              usertel1: this.$data.phone,
              usertel2: this.$data.secPhone
            };
            console.log(registerInfor);
             this.$axios({
              url:'/littleu/user/registerinfor',
              method:'post',
              data:registerInfor,
              headers: {
                'Content-Type': 'application/json;charset=utf-8'
              }
            }).then((resp) => {
             this.$router.push("/");
            });
          }else {
            this.$data.toastInstanse = Toast({
              message: '填写的信息不能为空！',
              position: 'middle',
              duration: 3000
            });
          }
        }else {
          this.$data.toastInstanse = Toast({
            message: '密码错误！',
            position: 'middle',
            duration: 3000
          });
        }


      }
    },
    components: {
      header1: header1
    },
    mounted() {
    },
    created() {
      var s = '1950-01-01 00:00:00';
      s = s.replace(/-/g, "/");
      var date = new Date(s);
      this.$data.starDate = date;
      var endDate = new Date();
      this.$data.endDate = endDate;
      console.log(this.$route.query.phone)
    }
  }
</script>

<style scoped>
* {
  text-align: left
}
  .inputBorder {
    border: 1px #c3c3c3 solid;
    border-radius: 4px;
  }

  .sendCaptcha {
    font-size: 12px;
  }

  .second {
    margin-top: 3%;
  }

  .prompt {
    font-size: 12px;
    color: grey;
  }

  .prompt1 {
    color: red;
  }

  .sendCaptcha {
    position: absolute;
    right: 5%;
    top: 17%;
    height: 48px;
  }

  .registSum {
    margin-top: 3%;
    width: 96%;
    margin-left: 2%;
    text-align: center;
  }

  .dateBox >>> input:disabled {
    background-color: white;
  }

  .sexCheck {
    height: 48px;
    border: 1px #c3c3c3 solid;
    border-radius: 4px;
  }

  .sexLable {
    float: left;
    width: 15%;
    font-size: 16px;
    text-align: center;
    line-height: 48px
  }

  .sexSelect {
    float: left;
    width: 60%;
    margin-top: 8px;
    margin-left: 15%;
  }
</style>
