<template>
  <div class="amap-page-container">
    <el-amap-search-box class="search-box" :search-option="searchOption" :on-search-result="onSearchResult"></el-amap-search-box>
    <el-amap ref="map" vid="amapDemo" :center="marker" :zoom="12" class="amap-demo" :events="events">
      <el-amap-marker :position="marker" visible="true" draggable="false"></el-amap-marker>
    </el-amap>
    <div class="toolbar">
      position: [{{ lng }}, {{ lat }}] address: {{ address }}
    </div>
  </div>
</template>

<script>
  // import { amapManager } from 'vue-amap';
  export default {
    name: "emap",
    data: function() {
      let self = this;
      return {
        lng: 0,
        lat: 0,
        searchOption: {
          city: '成都',
          citylimit: false
        },
        address: '',
        events: {
          init: (o)=>{
            console.log(this.$refs.map.$$getCenter());
            self.marker = this.$refs.map.$$getCenter();
          },
          click(e) {
            let { lng, lat } = e.lnglat;
            self.lng = lng;
            self.lat = lat;
            // 这里通过高德 SDK 完成。
            var geocoder = new AMap.Geocoder({
              radius: 1000,
              extensions: "all"
            });
            geocoder.getAddress([lng ,lat], function(status, result) {
              if (status === 'complete' && result.info === 'OK') {
                if (result && result.regeocode) {
                  self.address = result.regeocode.formattedAddress;
                  self.$nextTick();
                }
              }
            });
          }
        },
        marker: [121.59996, 31.197646]
      };
    },
    methods: {
      addMarker: function() {
        let lng = 121.5 + Math.round(Math.random() * 1000) / 10000;
        let lat = 31.197646 + Math.round(Math.random() * 500) / 10000;
        this.markers.push([lng, lat]);
      },
      onSearchResult(pois) {
        let latSum = 0;
        let lngSum = 0;
        if (pois.length > 0) {
          pois.forEach(poi => {
            let {lng, lat} = poi;
            lngSum += lng;
            latSum += lat;
            this.markers.push([poi.lng, poi.lat]);
          });
          let center = {
            lng: lngSum / pois.length,
            lat: latSum / pois.length
          };
          this.marker = [center.lng, center.lat];
        }
      }
    }
  }
</script>

<style scoped>
  .amap-demo {
    height: 300px;
  }
  .search-box {
    position: absolute;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
  }
  .amap-page-container {
    position: relative;
  }
</style>
