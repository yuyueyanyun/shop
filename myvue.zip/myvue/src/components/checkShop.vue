<template>
  <div class="addressShop">
    当前门店：
    <router-link to="/checkShop" tag="span">{{$store.state.shopName}}</router-link>
  </div>
</template>

<script>
  export default {
    name: "checkShop",
    data(){
        return {
          data: ''
        }
    }
  }
</script>

<style scoped>
  .addressShop {
    border-bottom: 1px black solid;
    padding: 1% 0 1% 2%;
    margin-top: 8px;
  }
</style>
