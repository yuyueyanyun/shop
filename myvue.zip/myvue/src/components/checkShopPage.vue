<template>
  <div>
    <header1 titleText="门店选择" leftShow="1" rightShow="1"/>
    <mt-radio
       class='leftb'
      title="门店选择"
      v-model="value"
      :options="options">
    </mt-radio>
    <mt-button class="submitBtn" type="primary" @click="checkRight">确定</mt-button>
  
  </div>

</template>

<script>
  import header1 from './header1';

  export default {
    name: "checkShopPage",
    data () {
      return {
        // 存放所选选项（字符串）
        value: '1',
        // radio的选项
        options : []
      }
    },
    methods: {
      checkRight(){
        this.$router.push({path:'/indexPage',query:{shop:this.$data.value}})
      }
    },
    components: {
      header1: header1
    },
    created(){
      this.$axios.get("/littleu/user/siteNameAll").then((resp)=>{
        console.log(resp.data);
        for(let i=0;i<resp.data.length;i++){
            this.$data.options.push(resp.data[i]);
        }
        console.log(this.$data.options);
      })
    }

  }
</script>

<style scoped>
.leftb{
  text-align: left;
}
  .submitBtn {
    width: 106%;
    position: fixed;
    bottom: 0px;
    left: -5%;
  }


</style>
