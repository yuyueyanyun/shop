<template>
  <div>
    <div class="orderBox" v-for="order in items">
      <div class="orderHeader" @click="getOrderDetails(order)">
        <h5>订单编号：{{order.orderId}}</h5>
        <h5>{{order.sendStatus}}</h5>
      </div>
      <div class="orderBody">
        <div>
          <p>门店：{{order.siteName}}</p>
          <p>收货人：{{order.receiver}}</p>
          <p>签收时间：{{order.time}}</p>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
    export default {
      data(){
        return {
          items:[],
        }
      },
      name: "signY",
      methods:{
        getOrderDetails(order) {
          var orderId=order.orderId
          console.log(orderId)
          this.$router.push({path:"/getOrder/getOrderDetails",query:{orderId:orderId}});
        },
      },
      created(){
        this.$axios.get('/littleu/distribution/selectWithSendStatus3').then(res=>{
          console.log(res);
          this.items=res.data;
        })
      }
    }
</script>

<style scoped>
  .orderBox{
    border-radius: 5px;
    margin: 15px 10px;
    padding: 5px;
    box-shadow: 0 0 5px grey;
    border-left: 5px solid #00C3F4;
  }
  .orderHeader{
    display: flex;
    justify-content: space-between;
    border-bottom: 1px dotted black;
  }
  .orderHeader>h5{
    margin: 5px 0;
  }
  .orderHeader>h5:last-child{
    color: #00C3F4;
  }
  .orderBody{
    align-items: center;
    font-size: 15px;
  }
  .orderBody>div:first-child{
    text-align: left;
  }
  .orderBody>div>p{
    margin: 2px 0;
  }
</style>
