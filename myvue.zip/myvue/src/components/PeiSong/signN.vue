<template>
  <div>
    <div class="orderBox" v-for="order in items">
      <div class="orderHeader" @click="getOrderDetails(order)">
        <h5>订单编号：{{order.orderId}}</h5>
        <h5>{{order.sendStatus}}</h5>
      </div>
      <div class="orderBody">
        <div>
          <p>门店：{{order.siteName}}</p>
          <p>收货人：{{order.receiver}}</p>
          <p>签收时间：{{order.time}}</p>
        </div>
        <!--<div class="confirm">-->
          <!--<button  @click="get">退回</button>-->
        <!--</div>-->
      </div>
    </div>
    <div class="mint-msgbox">
      <div class="mint-msgbox-content">
        <div class="mint-msgbox-message">是否退回?</div>
      </div>
      <div class="mint-msgbox-btns">
        <button class="mint-msgbox-btn mint-msgbox-cancel" @click="close">否</button>
        <button class="mint-msgbox-btn mint-msgbox-confirm " @click="sure">是</button>
      </div>
    </div>
    <div class="v-modal" style="z-index: 1;"></div>
  </div>
</template>

<script>
  import $ from 'jquery'
    export default {
      data(){
        return {
          items:[],
        }
      },
      name: "signN",
      methods:{
        getOrderDetails(order) {
          var orderId=order.orderId
          console.log(orderId)
          this.$router.push({path:"/getOrder/getOrderDetails",query:{orderId:orderId}});
        },
        get(){
          $(".mint-msgbox").css('display','block');
          $(".v-modal").css('display','block');
        },
        close(){
          $(".mint-msgbox").css('display','none');
          $(".v-modal").css('display','none');
        },
        sure(){
          this.$Message.success('确认成功');
        }
      },
      created(){
        this.$axios.get('/littleu/distribution/selectWithSendStatus4').then(res=>{
          console.log(res);
          this.items=res.data;
        })
      }
    }
</script>

<style scoped>
  @import '../../assets/order.css';
  @import '../../assets/msgbox.css';
</style>
