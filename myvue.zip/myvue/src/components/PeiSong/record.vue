<template>
  <div>
    <div>
      <mt-header title="配送记录">
        <mt-button  slot="left">
          <router-link to="/person" tag="li"><Icon type="ios-arrow-back" size="25"/></router-link>
        </mt-button>
      </mt-header>
    </div>
    <div class="headerList">
      <router-link to="/record/getOrder" tag="li">待取货</router-link>
      <router-link to="/record/sendOrder" tag="li">待送货</router-link>
      <router-link to="/record/signY" tag="li">签收成功</router-link>
      <router-link to="/record/signN" tag="li">签收失败</router-link>
    </div>
    <div>
      <router-view/>
    </div>
  </div>
</template>

<script>
    export default {
      name: "record",
    }
</script>

<style scoped>
  li{
    list-style: none;
  }
  .headerList{
    padding:0 5px;
    box-shadow: 0 5px 5px #d3d3d3;
    height: 40px;
    line-height: 40px;
    display: flex;
    justify-content: space-around;
  }
  .headerList>div{
    width: 20%;
  }
  li{
    list-style: none;
  }
</style>
