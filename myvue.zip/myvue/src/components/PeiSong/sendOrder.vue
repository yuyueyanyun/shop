<template>
  <div>
    <div class="orderBox" v-for="order in items">
      <div class="orderHeader" @click="getOrderDetails(order)">
        <h5>订单编号：{{order.orderId}}</h5>
        <h5 v-if="order.sendStatus==2">待送货</h5>
      </div>
      <div class="orderBody">
        <div>
          <p>门店：{{order.siteName}}</p>
          <p>收货人：{{order.receiver}}</p>
          <!--<p>剩余送货时间：</p>-->
          <!--<p>取货时间：</p>-->
        </div>
        <div class="confirm">
          <button @click="getOrder(order.orderId)">确认签收</button>
        </div>
      </div>
    </div>
    <div class="mint-msgbox">
      <div class="mint-msgbox-content">
        <div class="mint-msgbox-message">
          <div class="sign">
            <span>签收情况：</span>
            <select class="situation" @change="change">
      　　　　<option value="1">配送成功</option>
      　　　　<option value="2">配送失败</option>
        　　</select>
          </div>
          <div class="detailsTure">
            <span>成功详情：</span>
            <select @change="change" class="sitDetail">
      　　　　<option value="1">本人签收</option>
      　　　　<option value="2">物业签收</option>
      　　　　<option value="3">自提柜签收</option>
      　　　　<option value="4">他人代签收</option>
      　　　　<option value="5">其他</option>
        　　</select>
          </div>
          <div class="detailsFalse">
            <span>失败详情：</span>
            <select @change="change" class="sitDetailN">
        　　　　<option value="1">客户拒收</option>
        　　　　<option value="2">客户不在家</option>
        　　　　<option value="3">客户要求改期配送</option>
        　　　　<option value="4">其他</option>
        　　</select>
          </div>
          <div class="remarks">
            <span>备注：</span>
            <textarea name="" id="" cols="30" rows="2" class="orderTextarea"></textarea>
            <!--<Input id="textarea" cols="30"  maxlength="100" type="textarea" show-word-limit placeholder="请输入详细信息" style="width: 200px"/>-->
            <!--<van-cell-group>-->
              <!--<van-field type="textarea" style="border: 1px solid black"-->
                         <!--placeholder="请输入留言"-->
                         <!--show-word-limit/>-->
            <!--</van-cell-group>-->
          </div>
          <!--<div>-->
            <!--点击添加图片-->
          <!--</div>-->
        </div>
      </div>
      <div class="mint-msgbox-btns">
        <button class="mint-msgbox-btn mint-msgbox-cancel" @click="close">取消</button>
        <button class="mint-msgbox-btn mint-msgbox-confirm " @click="sure">确定</button>
      </div>
    </div>
    <div class="v-modal" style="z-index: 1;"></div>
  </div>
</template>

<script>
    import $ from 'jquery'
    export default {
      data(){
        myId:''
        return {
          items:[],
        }
      },
      name: "sendOrder",
      methods:{
        getOrderDetails(order) {
          var orderId=order.orderId
          console.log(orderId)
          this.$router.push({path:"/getOrder/getOrderDetails",query:{orderId:orderId}});
        },
        getOrder(orderId){
          $(".mint-msgbox").css('display','block');
          $(".v-modal").css('display','block');
          if ($(".situation").val()==2){
            $(".detailsTure").css('display','none');
            $(".detailsFalse").css('display','block')
          }
          else if ($(".situation").val()==1) {
            $(".detailsTure").css('display','block');
            $(".detailsFalse").css('display','none')
          }
          this.$data.myId=orderId;
          console.log(orderId)
        },
        close(){
          $(".mint-msgbox").css('display','none');
          $(".v-modal").css('display','none');
        },
        change(){
          if ($(".situation").val()==2){
            $(".detailsTure").css('display','none');
            $(".detailsFalse").css('display','block')
          }
          else if ($(".situation").val()==1) {
            $(".detailsTure").css('display','block');
            $(".detailsFalse").css('display','none')
          }
        },
        sure(){
          $(".mint-msgbox").css('display','none');
          $(".v-modal").css('display','none');
          if ($(".situation").val()==2){
            var success = false
            var describe = $(".sitDetailN option:checked").text()
          }
          else if ($(".situation").val()==1) {
            var success = true
            var describe = $(".sitDetail option:checked").text()
          }
          var memos = $(".orderTextarea").val()
          var myID=this.$data.myId
          console.log(myID)
          console.log(success)
          console.log(describe)
          console.log(memos)
          this.$axios({
            method: "put",
            url: "/littleu/distribution/sign",
            headers:{
              'Content-type': 'application/json;charset=utf-8'
            },
            data: JSON.stringify({orderId: myID, success: success, describe:describe, memos:memos}),
          }).then((res) => {
            // console.log(res.data);
          });
          // this.axios.get('http://172.17.2.248:8080/littleu/distribution/sign',
          //   {
          //     params:{orderId:"s0003", success:true, describe:describe, memos:memos}
          //   });
          this.$Message.success('送货成功');
          setTimeout(()=>{this.$router.go(0)},2000)
        }
      },
      created(){
        this.$axios.get('/littleu/distribution/selectWithSendStatus2').then(res=>{
          console.log(res);
          this.items=res.data;
        })
      }
    }
</script>

<style scoped>
  @import '../../assets/order.css';
  @import '../../assets/msgbox.css';

  .detailsTure,.detailsFalse{
    height: 36px;
    margin: 15px 0;
    display: none;
  }
  .detailsTure>span,.detailsFalse>span{
    float: left;
  }
  .detailsTure>select,.detailsFalse>select{
    float: right;
    height: 36px;
  }
  textarea{
    width: 200px;
    resize: none;
  }
  .sign,.remarks{
    display: flex;
    justify-content: space-between;
  }
  .remarks{
    margin-bottom: 50px;
  }
  select{
    width: 60%;
  }
  Input{
    resize:none;
    height: 100px!important;
  }
  .mint-msgbox-message{
    text-align: left;
  }
</style>
