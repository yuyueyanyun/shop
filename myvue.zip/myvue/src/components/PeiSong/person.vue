<template>
  <div>
    <div>
      <mt-header title="个人中心">
        <mt-button  slot="left">
          <router-link to="/delivery" tag="li">
            <Icon type="ios-arrow-back" size="25"/>
          </router-link>
        </mt-button>
      </mt-header>
    </div>
    <div class="user">
      <h2>{{name}}</h2>
      <p>已配送订单数：{{items[2]}}</p>
    </div>
    <div class="record">
      <h5>配送记录</h5>
      <div>
        <div><router-link to="/record/getOrder" tag="li">
          <Icon type="ios-albums" style="display: block;font-size: 30px"/>
          待取货<br>({{items[0]}})</router-link></div>
        <div><router-link to="/record/sendOrder" tag="li">
          <Icon type="md-car" style="display: block;font-size: 30px"/>
          待送货<br>({{items[1]}})</router-link></div>
        <div><router-link to="/record/signY" tag="li">
          <Icon type="md-checkmark-circle" style="display: block;font-size: 30px"/>
          签收成功<br>({{items[2]}})</router-link></div>
        <div><router-link to="/record/signN" tag="li">
          <Icon type="md-close-circle" style="display: block;font-size: 30px"/>
          签收失败<br>({{items[3]}})</router-link></div>
      </div>
    </div>
    <div>
      <h5>其他</h5>
      <div class="other">
        <div><router-link to="/person/changePwd" tag="li">修改密码</router-link></div>
        <!--<div><router-link to="" tag="li">联系客服</router-link></div>-->
      </div>
    </div>
    <div class="out" @click="get">
      <div>
        退出登录
      </div>
    </div>
    <div class="mint-msgbox">
      <div class="mint-msgbox-content">
        <div class="mint-msgbox-message">是否退出登录?</div>
      </div>
      <div class="mint-msgbox-btns">
        <button class="mint-msgbox-btn mint-msgbox-cancel" @click="close">否</button>
        <button class="mint-msgbox-btn mint-msgbox-confirm " @click="getOut">是</button>
      </div>
    </div>
    <div class="v-modal" style="z-index: 1;"></div>
  </div>
</template>

<script>
  import $ from 'jquery'
    export default {
      data(){
        return {
          items:[],
          name:'',
        }
      },
      name: "person",
      methods: {
        get(){
          $(".mint-msgbox").css('display','block');
          $(".v-modal").css('display','block');
        },
        close(){
          $(".mint-msgbox").css('display','none');
          $(".v-modal").css('display','none');
        },
        getOut(){
          $(".mint-msgbox").css('display','none');
          $(".v-modal").css('display','none');
          this.$Message.success('退出成功');
          setTimeout(()=>{
            this.$axios.get('/littleu/distribution/logout').then(res=>{
              console.log('2秒后返回首页')
            })
            this.$router.push("/")
            },2000)
        }
      },
      created(){
        this.$axios.get('/littleu/distribution/personalData').then(res=>{
          console.log(res);
          this.items=res.data.sendStatusCount;
          console.log(this.items)
          this.name=res.data.userName;
        })
      }
    }
</script>

<style scoped>
  @import '../../assets/msgbox.css';
  .user{
    margin-top: 30px;
  }
  li{
    list-style: none;
  }
  h5{
    text-align: left;
    padding: 0px 15px;
    margin: 15px 0;
  }
  .record>div{
    display: flex;
    justify-content: space-around;
  }
  .record>div>div>li{
    display: block;
    width: 75px;
    height: 75px;
    /*cursor: pointer;*/
    /*line-height: 75px*/
  }
  .record>div>div{
    width: 75px;
    height: 75px;
    background-color: white;
    box-shadow: 0 0 5px grey;
    border-radius: 5px;
  }
  .other>div{
    height: 40px;
    line-height: 40px;
    border-radius: 5px;
    margin: 20px;
    background-color: white;
    box-shadow: 0 0 5px grey;
  }
  .out{
    display: flex;
    justify-content: center;
  }
  .out>div{
    width: 60%;
    height: 40px;
    background-color: #00C3B6;
    color: white;
    line-height: 40px;
    text-align: center;
    margin-top: 40px;
    border-radius: 20px;
  }
</style>
