<template>
    <div>
      <div>
        <mt-header title="订单详情">
          <mt-button  slot="left">
            <router-link v-if="items2.sendStatus==1" to="/record/getOrder" tag="li"><Icon type="ios-arrow-back" size="25"/></router-link>
            <router-link v-if="items2.sendStatus==2" to="/record/sendOrder" tag="li"><Icon type="ios-arrow-back" size="25"/></router-link>
            <router-link v-if="items2.sendStatus==3" to="/record/signY" tag="li"><Icon type="ios-arrow-back" size="25"/></router-link>
            <router-link v-if="items2.sendStatus==4" to="/record/signN" tag="li"><Icon type="ios-arrow-back" size="25"/></router-link>
          </mt-button>
        </mt-header>
      </div>
      <div class="orderBox">
        <div class="orderHeader">
          <h5>订单编号：{{items2.orderId}}</h5>
          <h5 v-if="items2.sendStatus==1">待取货</h5>
          <h5 v-if="items2.sendStatus==2">待收货</h5>
          <h5 v-if="items2.sendStatus==3">签收成功</h5>
          <h5 v-if="items2.sendStatus==4">签收失败</h5>
        </div>
        <div class="orderBody">
          <div>
            <p>取货门店：{{items2.siteName}}</p>
            <p>收货人：{{items2.receiver}}</p>
            <p>电话：{{items1.tel1}}</p>
            <p>备用电话：{{items1.tel2}}</p>
            <p>收货地址：{{items1.address}}</p>
            <p>派单时间：{{items2.time}}</p>
          </div>
          <div class="left" v-if="items2.sendStatus==3 || items2.sendStatus==4">
            <h4>完成信息</h4>
            <p>签收情况：
              <span v-if="items2.sendStatus==3">签收成功</span>
              <span v-if="items2.sendStatus==4">签收失败</span>
            </p>
            <p>签收说明：{{items1.describe}}</p>
            <p>签收时间：{{items2.time}}</p>
          </div>
          <div>
            <h4>订单详情</h4>
            <p class="left">{{items1.sendType}}订单</p>
            <div class="table">
              <table>
                <tr>
                  <td>商品分类1</td>
                  <td>商品分类2</td>
                  <td>数量</td>
                </tr>
                <tr v-for="order in items3">
                  <td>{{order.goodsName1}}</td>
                  <td>{{order.goodsName2}}</td>
                  <td>{{order.goodsCount}}</td>
                </tr>
              </table>
            </div>
          </div>
          <div class="left">
            <p>箱数：{{items1.sendCount}}个</p>
            <p>重量：{{items1.sendWeight}}KG</p>
            <p>金额：{{items1.sendPrice}}元</p>
            <p>消耗箱子：{{items1.sendCount}}个</p>
          </div>
          <!--<div class="confirm">-->
            <!--<button>确认送达</button>-->
          <!--</div>-->
        </div>
      </div>
    </div>
</template>

<script>
    export default {
      name: "getOrderDetails",
      data(){

        return {
          items1:[],
          items2:[],
          items3:[],
          Id: null
        }
      },
      created(){
        console.log(this.$route.query)
        var Id=this.$route.query.orderId
        console.log(Id)
        this.axios.get('/littleu/distribution/selectAllGoodsDetails',
          {params:{orderId:Id}
          }).then((res) => {
            this.items1 = res.data.orderMessage;
            this.items2 = res.data.orderTaking;
            this.items3 = res.data.goodsDetailsList;
            console.log(res.data);
          });

        // this.$axios({
        //   method: "get",
        //   url: "/littleu/distribution/selectAllGoodsDetails",
        //   headers:{
        //     'Content-type': 'application/json;charset=utf-8'
        //   },
        //   params:{
        //     orderId:orderId,
        //     time:time
        //   },
        // }).then((res) => {
        //   this.items=res.data;
        //   console.log(this.items);
        // });
      }
    }
</script>

<style scoped>
  @import '../../assets/order.css';
  .table{
    display: flex;
    justify-content: center;
  }
  table{
    border-collapse:collapse;
    text-align: center;
    display: block;
  }
  tr,td{
    padding: 5px;
    border:1px solid grey;
  }
  .left{
    text-align: left;
  }
</style>
