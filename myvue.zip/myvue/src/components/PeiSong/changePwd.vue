<template>
    <div>
      <div class="header">
        <mt-header title="修改密码">
          <mt-button  slot="left">
            <router-link to="/person" tag="li"><Icon type="ios-arrow-back" size="25"/></router-link>
          </mt-button>
        </mt-header>
      </div>
      <div>
        <form action="">
          <Input class="pwdInput" @on-blur="oldPwd" v-model="value18" type="password" password placeholder="原密码" style="width: 80%" />
          <div class="selected">{{ value18 }}</div>
          <Input class="pwdInput" v-model="value19" type="password" password placeholder="新密码" style="width: 80%" />
          <div class="selected">{{ value19 }}</div>
          <Input class="pwdInput" v-model="value20" type="password" password placeholder="确认密码" style="width: 80%" />
          <div class="selected">{{ value20 }}</div>
        </form>
        <button class="changeBtn" @click="get">确认修改</button>
      </div>
      <div class="mint-msgbox">
        <div class="mint-msgbox-content">
          <div class="mint-msgbox-message">是否确认修改?</div>
        </div>
        <div class="mint-msgbox-btns">
          <button class="mint-msgbox-btn mint-msgbox-cancel" @click="close">否</button>
          <button class="mint-msgbox-btn mint-msgbox-confirm " @click="sure">是</button>
        </div>
      </div>
      <div class="v-modal" style="z-index: 1;"></div>
    </div>
</template>

<script>
  import $ from 'jquery'
    export default {
      data () {
        return {
          value18: '',
          value19:'',
          value20:''
        }
      },
      name: "changePwd",
      methods:{
        oldPwd(){
          console.log(this.$data.value18)
          $(".clickOld").css('visibility','visible');
        },
        get(){
          $(".mint-msgbox").css('display','block');
          $(".v-modal").css('display','block');
          console.log(this.$data.value18)
          console.log(this.$data.value19)
          console.log(this.$data.value20)
        },
        close(){
          $(".mint-msgbox").css('display','none');
          $(".v-modal").css('display','none');
        },
        sure(){
          if (this.$data.value19!=this.$data.value20) {
            this.$Message.error('新密码确认错误');
            console.log('新密码确认错误')
          }else if (this.$data.value19==this.$data.value20) {
            $(".mint-msgbox").css('display','none');
            $(".v-modal").css('display','none');
            console.log('新密码确认正确')
            var oldPwd=this.$data.value18
            var newPwd=this.$data.value20
            // this.$router.go(0)
            this.$axios({
              method: "put",
              url: "/littleu/distribution/changePassword",
              headers:{
                'Content-type': 'application/json;charset=utf-8'
              },
              data: JSON.stringify({password: oldPwd,newPassword:newPwd}),
            }).then((res) => {
              console.log(res.data);
              if (res.data==false){
                this.$Message.error('修改密码失败，原密码输入错误');
              }
              else if (res.data==true){
                this.$Message.success('新密码修改成功');
              }
            });
          }
        },
      }
    }
</script>

<style scoped>
  @import '../../assets/msgbox.css';
  .selected{
    display: none;

  }
  .clickOld{
    width: 80%;
    color: red;
    text-align: left;
    visibility: hidden;
  }
  form{
    display: flex;
    justify-content: center;
    text-align: center;
    flex-wrap: wrap;
  }
  .pwdInput{
    /*width: 70%;*/
    /*display: block;*/
    /*height: 40px!important;*/
    margin: 20px 0!important;
    /*background:none;*/
    /*outline:none;*/
    /*border:none;*/
    /*border: 1px solid #00C3B6;*/
    /*background-color: white;*/
    /*border-radius: 5px;*/
  }
  .changeBtn{
    width: 100px;
    height: 30px;
    background-color: orange;
    color: white;
    border: 0;
    border-radius: 15px;
    margin: 15px;
    outline: none;
  }
  li{
    list-style: none;
  }
</style>
