<template>
  <div>
    <div class="orderBox" v-for="order in items">
      <router-link  tag="div" :to="{path: '/getOrder/getOrderDetails/',query:{orderId:order.orderId}}" class="orderHeader" @click="getOrderDetails(order)">
        <h5>订单编号：{{order.orderId}}</h5>
        <h5 v-if="order.sendStatus==1">待取货</h5>
      </router-link>
      <div class="orderBody">
        <div>
          <p>门店：{{order.siteName}}</p>
          <p>收货人：{{order.receiver}}</p>
          <p>订单审核成功时间：{{order.time}}</p>
        </div>
        <div class="confirm">
          <button @click="get(order)">确认取货</button>
        </div>
      </div>
    </div>
    <router-view/>

    <div class="mint-msgbox">
      <div class="mint-msgbox-content">
        <div class="mint-msgbox-message">是否取货?</div>
      </div>
      <div class="mint-msgbox-btns">
        <button class="mint-msgbox-btn mint-msgbox-cancel" @click="close">否</button>
        <button class="mint-msgbox-btn mint-msgbox-confirm " @click="sure">是</button>
      </div>
    </div>
    <div class="v-modal" style="z-index: 1;"></div>
  </div>
</template>

<script>
    import $ from 'jquery'
    export default {
      data(){
        myId:''
        return {
          items:[],
          myOrderData:'',
          orderId: null
        }
      },
      name: "getOrder",
      methods:{
        getOrderDetails(order) {
          var orderId=order.orderId
          // console.log(orderId)
          // this.$router.push({path:"/getOrder/getOrderDetails",query:{orderId:orderId}});
          // this.$axios({
          //   method: "get",
          //   url: "http://172.17.2.248:8080/littleu/distribution/selectAllGoodsDetails",
          //   headers:{
          //     'Content-type': 'application/json;charset=utf-8'
          //   },
          //   data: JSON.stringify({
          //     orderId: orderId,
          //     siteName: siteName,
          //     receiver:receiver,
          //     sendStatus:sendStatus,
          //     time:time
          //   }),
          // }).then((res) => {
          //   this.myData=res.data;
          //   console.log(this.myData);
          // });
        },
        get(order){
          $(".mint-msgbox").css('display','block');
          $(".v-modal").css('display','block');
          console.log(order.orderId)
          this.$data.myId=order.orderId;

        },
        close(){
          $(".mint-msgbox").css('display','none');
          $(".v-modal").css('display','none');
        },
        sure(){
          $(".mint-msgbox").css('display','none');
          $(".v-modal").css('display','none');
          var myID=this.$data.myId
          console.log(myID)
          this.$axios({
            method: "put",
            url: "/littleu/distribution/delivery",
            headers:{
              'Content-type': 'application/json;charset=utf-8'
            },
            data: JSON.stringify({orderId: myID}),
          }).then((res) => {
            // console.log(res.data);
          });
          this.$Message.success('取货成功');
          setTimeout(()=>{this.$router.go(0)},2000)
        }
      },
      created(){
        this.$axios.get('/littleu/distribution/selectWithSendStatus1').then(res=>{
          console.log(res);
          this.items=res.data;
        })
      }
    }
</script>

<style scoped>
  @import '../../assets/order.css';
  @import '../../assets/msgbox.css';
</style>
