<template>
  <div>
    <mt-header title="抢单配送">
      <mt-button  slot="left">
        <router-link to="/person" tag="li"><Icon type="ios-person" size="25"/></router-link>
      </mt-button>
      <!-- <mt-button  slot="right" @click="goNews">
        <Icon type="md-chatboxes" size="25"/>
      </mt-button> -->
    </mt-header>
    <div class="screen">
      <Select v-model="selected" >
        <Option v-for="site in siteName" :value="site" :key="site">{{site}}</Option>
      </Select>
      <Button @click="saixuan">筛选</Button>
    </div>
    <div class="selected">{{ selected }}</div>
    <div class="orderBox" v-for="order in items">
      <div class="orderHeader">
        <h5>订单编号：{{order.orderId}}</h5>
        <h5>{{order.siteName}}</h5>
      </div>
      <div class="orderBody">
        <div>
          <p>距离：{{order.distance}}km</p>
          <p>重量：{{order.sendWeight}}kg</p>
          <p>箱数：{{order.sendCount}}</p>
          <p>收货地址：{{order.address}}</p>
          <p>到货时间：<span>48小时以内</span></p>
        </div>
        <div class="notgetOrder" @click="get(order)">
          抢单
        </div>
      </div>
    </div>
    <!--<button class="beginOrder">开始接单</button>-->
    <div class="mint-msgbox">
      <div class="mint-msgbox-content">
        <div class="mint-msgbox-message">是否接单?</div>
      </div>
      <div class="mint-msgbox-btns">
        <button class="mint-msgbox-btn mint-msgbox-cancel" @click="close">否</button>
        <button class="mint-msgbox-btn mint-msgbox-confirm " @click="sure">是</button>
      </div>
    </div>
    <div class="v-modal" style="z-index: 1;"></div>
  </div>

</template>

<script>
    import $ from 'jquery'
    export default {
      data(){
        myId:'';
        return {
          items:[],
          siteName: [],
          selected: ''
        }
      },

      name: "delivery",
      methods:{
        saixuan(){
          var zhandianID=$('.selected').text()
          console.log($('.selected').text())
          this.axios.get('/littleu/distribution/selectBySiteName',
            {
              params:{siteName:zhandianID}
            }).then((res) => {
            console.log(res.data);
              this.items=res.data;
            })
        },
        goNews(){
          this.$router.push("/news");
        },
        get(order){
          $(".mint-msgbox").css('display','block');
          $(".v-modal").css('display','block');
          console.log(order.orderId)
          this.$data.myId=order.orderId;

        },
        close(){
          $(".mint-msgbox").css('display','none');
          $(".v-modal").css('display','none');
        },
        sure(){
          $(".mint-msgbox").css('display','none');
          $(".v-modal").css('display','none');
          var myID=this.$data.myId
          console.log(myID)
          this.$axios({
            method: "put",
            url: "/littleu/distribution/orderTaking",
            headers:{
              'Content-type': 'application/json;charset=utf-8'
            },
            data: JSON.stringify({orderId: myID}),
          }).then((res) => {
            // console.log(res.data);
          });
          this.$Message.success('接单成功');
          setTimeout(()=>{this.$router.go(0)},2000)
        }
      },
      created(){
        this.$axios.get('/littleu/distribution/selectAllSiteName').then(res=>{
          console.log(res);
          this.items=res.data;
        }),
        this.$axios.get('/littleu/distribution/siteName').then(res=>{
          console.log(res);
          this.siteName=res.data;
        })
      }
    }
</script>

<style scoped>
  @import '../../assets/msgbox.css';
  .mint-msgbox{
    display: none;
  }
  .screen{
    height: 30px;
    display: flex;
    margin-top: 30px;
    justify-content: space-between;
    padding: 0 15px;
  }
  .selected{
    display: none;
  }
  .orderBox{
    border-radius: 5px;
    margin: 15px 10px;
    padding: 5px;
    box-shadow: 0 0 5px grey;
    border-left: 5px solid #00C3F4;
  }
  .orderHeader{
    display: flex;
    justify-content: space-between;
    border-bottom: 1px dotted black;
  }
  .orderHeader>h5{
    margin: 5px 0;
  }
  .orderHeader>h5:last-child{
    color: #00C3F4;
  }
  .orderBody{
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 15px;
  }
  .orderBody>div:first-child{
    text-align: left;
  }
  .getOrder{
    color: orange;
  }
  .notgetOrder{
    width: 50px;
    height: 50px;
    text-align: center;
    line-height: 50px;
    background-color: orange;
    color: white;
    border-radius: 25px;
  }
  .orderBody>div>p{
    margin: 2px 0;
  }
  /*.beginOrder{*/
    /*margin: 0;*/
    /*padding: 0;*/
    /*border: 5px solid rgba(0, 195, 244, 0.31);*/
    /*background-color: #00C3F4;*/
    /*outline: none;*/
    /*width: 100px;*/
    /*height: 100px;*/
    /*position: fixed;*/
    /*border-radius: 50px;*/
    /*left: 0px;*/
    /*right: 0px;*/
    /*bottom: 5px;*/
    /*margin: auto;*/
    /*font-size: 18px;*/
    /*color: white;*/
    /*font-weight: bolder;*/
  /*}*/
</style>
