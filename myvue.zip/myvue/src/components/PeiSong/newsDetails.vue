<template>
  <div>
    <div>
      <mt-header title="订单消息">
        <mt-button  slot="left">
          <router-link to="/news" tag="li"><Icon type="ios-arrow-back" size="25"/></router-link>
        </mt-button>
      </mt-header>
    </div>
    <div class="newBox" @click="">
      <div>
        <h4>订单消息</h4>
        <p>亲爱的配送员，您选择退货的编号为<span>111111111111</span>的订单已退货成功，签收情况：本人签收，
          签收时间：<span>2019-12-23 19:52:28。</span></p>
        <h4>2019-12-24 15:07:05</h4>
      </div>
    </div>
  </div>
</template>

<script>
    export default {
        name: "newsDetails"
    }
</script>

<style scoped>
  @import '../../assets/news.css';
</style>
