<template>
  <div>
    <mt-button class="submitBtn" type="primary">{{subText}}</mt-button>
  </div>


</template>

<script>
  export default {
    name: "submitBtn",
    props:["subText"]
  }
</script>

<style scoped>
  .submitBtn {
    width: 90%;
    position: absolute;
    left: 5%;
    bottom: 10px;
  }
</style>
