<template>
  <div>
    <header1 titleText="订单详情" rightShow="1" leftShow="1"/>
    <div class="orderState">
      <p v-if="item1.verifyStatus=='成功'">当前订单已经分为两个包裹</p>
      <p v-if="item1.verifyStatus=='失败'">您的订单审核失败，请重新尝试</p>
      <p v-if="item1.verifyStatus=='失败'">审核失败</p>
      <p v-if="item1.verifyStatus=='成功'">{{item1.verifyStatus}}</p>
      <p v-if="item1.verifyStatus=='待审核'">您的订单正在审核中，请耐心等待!</p>
      <p v-if="item1.verifyStatus=='待审核'">{{item1.verifyStatus}}</p>
      <p>提交时间：{{item1.submitDate}}</p>
    </div>
    <p class="orderId">订单编号:{{item1.orderId}}</p>
    <div class="orderMes">
      <div><Icon type="ios-clock" /></div>
      <div class="orderDet">
        <p>收件人：{{item1.receiver}}</p>
        <p>电话：{{item1.tel1}}</p>
        <p>备用电话:{{item1.tel2}}</p>
        <div v-if="item2!=null">
          <p>收银台编号：{{item2.moneyNum}}</p>
          <p>流水号：{{item2.spendNum}}</p>
          <p>日期:{{item2.ticketDate}}</p>
        </div>
        <div v-else>
          <p>收银台编号：暂无</p>
          <p>流水号：暂无</p>
          <p>日期:暂无</p>
        </div>

      </div>
      <div>
        <i class="iconfont  icon-iconfontjiantou4"></i>
      </div>
    </div>
  </div>
</template>

<script>
  import header1 from "./header1"

  export default {
    name: "applyDetail",
    data(){
      return {
        text:{

        },
        item1:[],
        item2:[],
      }
    },
    components: {
      header1: header1
    },
    created(){
      // console.log(this.$router.query.orderId);
      this.$axios.get("/littleu//user/selectOrderDetails",
        {params:{
          orderId:this.$route.query.orderId
          }}).then((resp)=>{
            console.log(resp.data);
            this.item1=resp.data.orderDetailUp;
            this.item2=resp.data.orderDetialDown;
            console.log(this.$data.item2);
            // this.$data.mes.orderId=resp.data.orderId;
            // this.$data.mes.date1=resp.data.submitDate;
            // this.$data.mes.address=resp.data.address;
            // this.$data.mes.receiver=resp.data.receiver;
            // this.$data.mes.tel1=resp.data.tel1;
            // this.$data.mes.tel2=resp.data.tel2;
            // this.$data.mes.verifyStatus=resp.data.verifyStatus;
            // this.
      })
    }
  }
</script>

<style scoped>
*{
  text-align: left;

}
  .orderState{
    padding: 2% 0 2% 5%;
    background-color: #e1dfdc;
  }
  .orderId{
    margin-left: 5%;
    width: 90%;
    line-height: 20px;
    margin-top: 2%;
  }
  .orderMes{
    background-color: #faf8f5;
    padding: 2% 0 2% 5%;
    height: 147px;
  }
  .orderMes>div{
    float: left;
  }
  .orderMes div:nth-child(1){
    line-height: 147px;
  }
  .orderMes div:nth-child(3){
    line-height: 147px;
  }
  .orderMes div:nth-child(2){
    margin-left: 5%;
    width: 80%;
    border-left: 1px grey dashed;
    padding-left: 2%;
  }
</style>
