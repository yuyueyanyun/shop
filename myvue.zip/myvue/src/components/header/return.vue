<template>
  <div class="header">
    <mt-header :title="title">
      <span v-on:click='cback' slot="left">
        <mt-button icon="back">返回</mt-button>
      </span>
    </mt-header>
    <!--新建地址-->
    <slot name="menu">
    </slot>
    <!--保存新建地址-->
    <slot name="save">
    </slot>
    <slot name="user">
    </slot>
  </div>
</template>

<script>
export default {
  name: "return",
  props: {
    title: String  // 字符串
  },
  methods: {
    cback () {
      this.$router.go(-1)  // 返回上一层
    }
  }
}
</script>

<style scoped>
  .header {
    position: relative;
  }
  header+div{
    position: absolute;
    top: 0;
    right: 10px;
    height: 100%;
    color: #fff;
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
  header+div>p {
    font-size: 14px;
  }
</style>
