<template>
  <div>
    <header1 titleText="我的申请" rightShow="1" leftShow="1"/>
    <div class="dateBox">
      <DatePicker class="dPicker" v-model="startDate" @on-change="getData" type="date" placement="bottom-end"
                  placeholder="起始日期" style="width:32%"></DatePicker>
      <DatePicker class="dPicker" v-model="endDate" @on-change="getData" type="date" placement="bottom-end"
                  placeholder="截止日期" style="width: 32%"></DatePicker>
      <Select v-model="applyType" @on-change="chooseType" style="width:32%">
        <Option value="">全部</Option>
        <Option value="待审核">待审核</Option>
        <Option value="成功">审核通过</Option>
        <Option value="失败">审核失败</Option>
      </Select>
    </div>
    <div class="applyList">
      <router-link
        v-for="item in applyMes"
        :to="{path:'/applyDetail',query:{orderId:item.orderId}}"
        class="applyCard"
        tag="div" :key="item.orderId">
        <div class="applyHeader">
          订单编号：{{item.orderId}}
          <span class="applyState">{{item.verifyStatus}}</span>
        </div>
        <div class="cardBody">
          <p>门店：{{item.siteName}}</p>
          <p>收货人：{{item.receiver}}</p>
          <p class="time">
            <span class="orderTime">最后修改时间：{{item.date}}</span>
          </p>
        </div>
        <div class="cardFooter">
          <p>提交时间：{{item.submitDate}}</p>
        </div>
      </router-link>

    </div>

  </div>

</template>

<script>
  import header1 from './header1';

  export default {
    name: "apply",
    data() {
      return {
        applyType: "",
        startDate: "",
        endDate: "",
        applyMes: []
      }
    },
    components: {
      header1: header1
    },
    methods: {
      getData() {
        if (this.$data.startDate != "" && this.$data.endDate != "") {
          if(this.$data.applyType==undefined){
              this.$data.applyType="";
          }
          var mes = {
            'startTime': this.$data.startDate,
            'endTime':new Date((this.$data.endDate/1000+86400)*1000),
            'VS': this.$data.applyType
          };
          console.log(mes);
          this.$axios.get("/littleu//user/selectUserApplication",
            {
              params: mes
            },
            {
              headers: {'ContentType': 'application/json;charset=utf-8'}
            }
          ).then((resp) => {
                console.log(resp);
            this.$data.applyMes = [];
            for (let i = 0; i < resp.data.length; i++) {
              var date1;
              var text1;
              var url;
              if (resp.data[i].verifyStatus == "待审核") {
                date1 = resp.data[i].submitDate;
                text1 = "提交"
              } else {
                date1 = resp.data[i].verifyTime;
                text1 = "审核"
              }
              var obj = {
                orderId: resp.data[i].orderId,
                receiver: resp.data[i].receiver,
                siteName: resp.data[i].siteName,
                verifyStatus: resp.data[i].verifyStatus,
                date: date1,
               text: text1,
              submitDate:resp.data[i].submitDate
              };
              this.$data.applyMes.push(obj);
            }
          })
        }
      },
      chooseType(value) {
        var mes = {
          'startTime': this.$data.startDate,
          'endTime':new Date((this.$data.endDate/1000+86400)*1000),
          'VS': value
        };
        this.$axios.get("/littleu//user/selectUserApplication",
          {
            params: mes
          },
          {
            headers: {'ContentType': 'application/json;charset=utf-8'}
          }
        ).then((resp) => {
          console.log(resp);
          this.$data.applyMes = [];
          for (let i = 0; i < resp.data.length; i++) {
            var date1;
            var text1;
            var url;
            if (resp.data[i].verifyStatus == "待审核") {
              date1 = resp.data[i].submitDate;
              text1 = "下单"
            } else {
              date1 = resp.data[i].verifyTime;
              text1 = "审核"
            }
            var obj = {
              orderId: resp.data[i].orderId,
              receiver: resp.data[i].receiver,
              siteName: resp.data[i].siteName,
              verifyStatus: resp.data[i].verifyStatus,
              date: date1,
              text: text1,
              submitDate:resp.data[i].submitDate
            };
            this.$data.applyMes.push(obj);
          }
        })
      }
    },
    created() {
      var mes = {
        'startTime': this.$data.startDate,
        'endTime': this.$data.endDate,
        'VS': this.$data.applyType
      };
      this.$axios.get("/littleu//user/selectUserApplication",
        {
          params: mes
        },
        {
          headers: {'ContentType': 'application/json;charset=utf-8'}
        }
      ).then((resp) => {
        console.log(resp);
          this.$data.applyMes = [];
          for (let i = 0; i < resp.data.length; i++) {
            var date1;
            var text1;
            var url;
            if (resp.data[i].verifyStatus == "待审核") {
              date1 = resp.data[i].submitDate;
              text1 = "下单"
            } else {
              date1 = resp.data[i].verifyTime;
              text1 = "审核"
            }
            var obj = {
              orderId: resp.data[i].orderId,
              receiver: resp.data[i].receiver,
              siteName: resp.data[i].siteName,
              verifyStatus: resp.data[i].verifyStatus,
              date: date1,
                text: text1,
              submitDate:resp.data[i].submitDate
            };
            this.$data.applyMes.push(obj);
          }
        }
      )
    }
  }
</script>

<style scoped>
*{
  text-align: left;
}
  .dPicker {
    float: left;
  }

  .dateBox {
    margin-top: 10px;
    height: 40px;
    margin-left: 3%;
  }

  .applyCard {
    margin-top: 8px;
    width: 90%;
    margin-left: 5%;
    border: 1px #c8c8c8 solid;
    box-shadow: 1px 1px 1px 1px #c8c8c8;
    padding-bottom: 1%;
  }

  .applyHeader {
    width: 94%;
    margin-left: 3%;
    border-bottom: 1px #c8c8c8 solid;
    line-height: 30px;
    padding: 1% 1% 0px 2%;
  }

  .applyState {
    color: grey;
    float: right;
    margin-right: 2%;
  }

  .cardBody {
    width: 90%;
    margin-left: 5%;
    margin-top: 1%;

  }

  .cardFooter {
    width: 90%;
    margin-left: 5%;
    margin-top: 1%;
    border-top: 1px black dashed;
  }

</style>
