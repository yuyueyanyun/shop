<template>
  <div>
    <header1 titleText="个人中心"  rightShow="2" leftShow="1"/>
    <div class="userMes">
      <div class="imgUpload">
        <Upload
          ref="upload"
          :show-upload-list="false"
          :on-success="handleSuccess"
          :max-size="2048"
          multiple
          type="drag"
          action="//jsonplaceholder.typicode.com/posts/">
          <div class="imgBox">
            <img style=" width: 75px;height: 75px;" :src="$store.state.userImgUrl">
          </div>
        </Upload>
      </div>
      <div class="userMessage">
        <p v-if="login==1">{{userMessage.userName}}</p>
        <p v-if="login==1">{{userMessage.userPhone}}</p>
        <p v-if="login==0">请先登陆</p>
      </div>
    </div>
    <p class="titleUserMes">订单</p>
    <router-link to="myApply" tag="div" class="myApply">
      <span>我的申请</span><span class="centerIcon"><Icon type="ios-arrow-forward" /></span>
    </router-link>
    <router-link to="/distribution/soon" tag="div" class="myApply">
      <span>我的物流</span><span class="centerIcon"><Icon type="ios-arrow-forward" /></span>
    </router-link>
    <div class="sendCheck">
      <router-link to='/distribution/soon' tag='div' class="sendPart">
        <p class="textCenter">待配送</p>
        <p class="textCenter">({{countArr[0]}})</p>
      </router-link>
      <router-link to='/distribution/ing' tag='div' class="sendPart">
        <p class="textCenter">配送中</p>
        <p class="textCenter">({{countArr[1]}})</p>
      </router-link>
      <router-link to='/distribution/success' tag='div' class="sendPart">
        <p class="textCenter">已签收</p>
        <p class="textCenter">({{countArr[2]}})</p>
      </router-link>
      <router-link to='/distribution/failure' tag='div' class="sendPart">
        <p class="textCenter">签收失败</p>
        <p class="textCenter">({{countArr[3]}})</p>
      </router-link>
    </div>
    <p class="titleUserMes">其他</p>
    <router-link to="/userAddr" tag="div" class="myApply">
      <span>我的地址</span><span class="centerIcon"><Icon type="ios-arrow-forward" /></span>
    </router-link>
   <mt-button class="submitBtn" @click="outLogin" type="primary" v-if="login==1">退出登录</mt-button>
    <router-link to="/" v-if="login==0" tag="div">
      <mt-button class="submitBtn" type="primary">前往登录</mt-button>
    </router-link>

  </div>

</template>

<script>
  import header1 from './header1';
  import submintBtn from './submitBtn'
  import { MessageBox } from 'mint-ui';
  export default {
    name: "userCenter",
    data() {
      return {
        messageBox:null,
        login:0,
        userMessage: {
          userImg: '',
          userName: '',
          userPhone: ''
        },
        countArr:[0,0,0,0]
      }
    },
    components: {
      header1: header1,
      submintBtn:submintBtn
    },
    methods:{
      handleSuccess(){

      },
      outLogin(){
        this.messageBox=MessageBox({
          title: '提示',
          message: '确定要退出登陆吗?',
          showCancelButton: true
        }).then(()=>{
         this.$axios.get("littleu/user/logout").then((resp)=>{

         });
          this.$router.push('/');
        });
      }
    },
    created(){
      this.$axios.get("/littleu/user/personalCenter").then((resp)=>{
        console.log(resp);
        if(resp.data!=''){
          this.$data.login=1;
          this.$data.userMessage.userName= resp.data.personinformation.username;
          this.$data.userMessage.userPhone=resp.data.personinformation.usertel1;
          // this.$store.state.userImgUrl=resp.data.personinformation.userpic;
          for(let i=0;i<4;i++){
            this.$data.countArr[i]=resp.data.sendStatus[i];
          }
        }else {
          this.$data.login=0;
          for(let i=0;i<4;i++){
            this.$data.countArr[i]=0;
          }
        }


      })
    }
  }
</script>

<style scoped>
* {
  text-align: left;
}
  .userMes {
    background-color: #afafaf;
    width: 100%;
    height: 150px;
    padding: 7% 0 10% 10%;
  }

  .imgUpload {
    width: 75px;
    height: 75px;
    border-radius: 50px;
    background-color: #fffdfa;
    float: left;
    overflow: hidden;
  }
  .imgUpload>>>.ivu-upload{
    width: 75px;
    height: 75px;
    border: none;
  }
  .userMessage {
    float: left;
    margin-left: 10%;
    margin-top: 22px;
  }

  .titleUserMes {
    margin-left: 5%;
    width: 90%;
    font-size: 18px;
    margin-top: 10px;
  }

  .myApply {
    margin-top: 2px;
    padding: 10px 5% 10px;
    background-color: #d4d4d4;
  }

  .centerIcon {
    float: right;
    margin-right: 3%;
  }
  .sendCheck{
   height: 90px;
    margin-top: 5px;
  }
  .sendCheck>div{
    margin-left: 5px;
    width: 90px;
    height: 90px;
    background-color: #f8f8f8;
  }
  .sendCheck div:nth-child(1){
    margin-left: 0px;
  }
  .sendPart{
    float: left;
  }
  .textCenter{
    text-align: center;
  }
  .sendPart p:nth-child(1){
    margin-top: 25%;
  }
  .userHeaderImg{
    width: 75px;
    height: 75px;
  }
   .submitBtn {
    width: 90%;
    position: absolute;
    left: 5%;
    bottom: 10px;
    text-align: center;
  }
</style>
