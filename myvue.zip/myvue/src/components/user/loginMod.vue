<template>
  <div class="fromLogin">
    <div class="userId" v-if="v ==='0'">
      <van-field
        v-model.lazy="txt.userId"
        :placeholder="numP"
        @change="getId"
        @input="setIdReg"
        :error-message="reg.id"
      />
    </div>
    <div class="userId" v-if="v ==='1'">
      <van-field
        v-model.lazy="txt.userId"
        :placeholder="numP"
        @change="getIdW"
        @input="setIdReg"
        :error-message="reg.id"
      />
    </div>
    <div class="userPwd">
      <van-field
        v-model.lazy="txt.userPwd"
        type="password"
        :placeholder="pwdP"
        @change="getPwd"
        @input="setPwdReg"
        :error-message="reg.pwd"
      />
    </div>
    <div class="otherUrl" v-if="v ==='0'">
      <router-link to='/forget' tag="p">忘记密码</router-link>
    </div>
    <div class="loginBtn" v-if="v === '0'">
      <button type="button" @click="login">登陆</button>
    </div>
    <div class="loginBtn" v-if="v === '1'">
      <button type="button" @click="loginW">登陆</button>
    </div>
    <div class="registerBtn" v-if="v === '0'">
      <router-link tag="button" to="/regist">注册</router-link>
    </div>
  </div>
</template>

<script>
import { mapMutations } from 'vuex'
export default {
  name: 'loginMod',
  props: {
    numP: String,
    pwdP: String,
    v: String
  },
  data: function () {
    return {
      reg: {
        id: '',
        pwd: ''
      },
      txt: {
        userId: '',
        userPwd: ''
      }
    }
  },
  // 数据监听 v 改变时
  watch: {
    v: function () {
      this.reg.id = ''
      this.reg.pwd = ''
      this.txt.userPwd = ''
      this.txt.userId = ''
    }
  },
  methods: {
    // 重置
    setIdReg: function () {
      this.reg.id = ''
    },
    setPwdReg: function () {
      this.reg.pwd = ''
    },
    // 判断账号  用户
    getId: function () {
      var phone = this.txt.userId
      // console.log(!(/^1[3456789]\d{9}$/.test(phone)));
      if (!/^1[3456789]\d{9}$/.test(phone)) {
        this.reg.id = '手机号格式错误'
      } else {
        this.reg.id = ''
      }
    },
    getIdW: function () {
      var id = this.txt.userId
      // console.log(!(/^1[3456789]\d{9}$/.test(phone)));
      if (!id) {
        this.reg.id = '账号不能为空'
        console.log(this.reg)
      } else {
        this.reg.id = ''
      }
    },
    getPwd: function () {
      var pwd = this.txt.userPwd
      console.log(pwd.length)
      if (!!pwd) {
        this.reg.pwd = ''
      } else {
        this.reg.pwd = '密码输入错误'
      }
    },
    // 登陆  用户  发送用户请求
    login: function () {
      mapMutations(['changeLogin'])    // 1111111
      // this.$router.push({ path: '/indexPage' }) // 测试流程
      var id = this.txt.userId
      var pwd = this.txt.userPwd
      console.log(id, pwd)
      if (!id) {
        return this.reg.id = '账号不能为空';
      }
      if (!pwd) {
        return this.reg.pwd = '密码不能为空';
      }
      if (this.reg.id === '' && this.reg.pwd === '') {
        // console.log(id, pwd)
        this.$axios.post('/littleu/user/login', {
          useraccount: id,
          userpassword: pwd
        }).then((resp) => {
          console.log(resp)
          _this.userToken = 'Bearer ' + res.data.data.body.token; //1111111111111
          // 将用户token保存到vuex中
          _this.changeLogin({ Authorization: _this.userToken });  //111111111111111
          if (resp.data == true) {
            this.$router.push({ path: '/indexPage' })
          } else {
            this.reg.pwd = '账号或密码错误'
          }
        }).catch((err) => {
          console.log('失败')
          console.log(err)
        })
      }
    },
    // 发送配送员请求
    loginW: function () {
      var id = this.txt.userId
      var pwd = this.txt.userPwd
      // this.$router.push({ path: '/delivery' }) // 测试流程
      if (this.reg.id === '' && this.reg.pwd === '' && !!id && !!pwd) {
        this.$axios.post('/littleu/distribution/senderLogin', {
          userAccount: id,
          userPassword: pwd
        }).then((resp) => {
          console.log(resp)
          if (resp.data == true) {
            this.$router.push({ path: '/delivery' })
          } else {
            this.reg.pwd = '账号或密码错误'
          }
        }).catch((err) => {
          console.log('失败')
          console.log(err)
        })
      }
    }
  }
}
</script>

<style scoped>
input,
button {
  display: inline-block;
  width: 100%;
  height: 100%;
  outline: none;
}
input::placeholder {
  color: #7e7d81;
}
.fromLogin {
  display: flex;
  flex-direction: column;
  align-items: center;
}
.fromLogin > div {
  width: 80%;
}
.fromLogin > .otherUrl {
  width: 80%;
  padding-top: 20px;
  padding-bottom: 20px;
  text-align: right;
  font-size: 14px;
}
.loginBtn,
.registerBtn {
  box-sizing: border-box;
  height: 50px;
  padding: 0 10px;
}
.loginBtn {
  margin-bottom: 20px;
}
.loginBtn button {
  color: #0a6cd6;
  font-size: 16px;
  font-weight: 600;
}
.registerBtn button {
  background-color: #fff;
  outline: 1px solid #dddddd;
  color: #86878a;
  font-size: 16px;
  font-weight: 600;
}
</style>
