<template>
  <div class="page">
    <mt-header title="小U到家">
      <mt-switch v-model="checks" slot="right">
        <label>{{checkUser}}</label>
      </mt-switch>
    </mt-header>
    <div class="logo"><img src="../../assets/logo.png" alt=""></div>
    <log v-if="checkUser ==='用户端'" numP="请输入手机号" pwdP="请输入密码" v="0"></log>
    <log v-else-if="checkUser ==='配送端'" numP="请输入账号" pwdP="请输入密码" v="1"></log>
  </div>

</template>

<script>
  import log from "./loginMod"
    export default {
      name: "loginU",
      components: {
        log: log
      },
      data: function () {
        return {
          checks: false, // 绑定的是字符串，则会转化为true或false
          checkUser: '用户端'
        }
      },
      watch:{
        checks: function (val) { // 实时监听数据变化
          this.checked_fun(val)
        }
      },
      methods: { // 方法
        checked_fun: function (val) {
          console.log(this);
          if(val){
            this.checkUser = "配送端"
          }else {
            this.checkUser = "用户端"
          }
        }
      }
    }
</script>

<style scoped>
  .page {
    width: 100%;
    height: 100%;
    background-color: #f7f8fa;
  }
  .mint-header-title {
    font-size: 32px;
  }
  .mint-switch-label label {
    display: inline-block;
    width: 40px;
    font-size: 14px;
  }
  .mint-switch-core {
    height: 28px;
  }
  .logo {
    height: 168px;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .logo>img {
    width: 20%;
  }

</style>
