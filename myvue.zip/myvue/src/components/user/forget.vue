<template>
  <div>
    <heade title="忘记密码"></heade>
    <div class="second widthBox">
      <mt-field
        class="inputBorder"
        :state="phoneState"
        label="手机号"
        placeholder="请输入手机号"
        type="tel"
        v-model="phone"
        @input="checkPhone"
      ></mt-field>
    </div>
    <div class="second widthBox">
      <mt-field
        class="inputBorder"
        ref="captcha"
        label="验证码"
        placeholder
        type="text"
        v-model="captch"
      ></mt-field>
      <mt-button class="sendCaptcha" :disabled="checkNo" type="primary" @click="sendCaptcha">发送验证码</mt-button>
      <div class="prompt" style="display: none" ref="capPrompt">*发送验证码成功，{{restTime}}s后可以再次发送</div>
    </div>
    <div class="second widthBox">
      <mt-field
        class="inputBorder"
        label="密码"
        placeholder="请输入密码"
        type="password"
        v-model="pwd1"
        @input="tPwd"
      ></mt-field>
    </div>
    <div class="second widthBox">
      <mt-field
        class="inputBorder"
        :state="setPwd"
        label="密码"
        placeholder="请再次确认密码"
        type="password"
        v-model="pwd2"
        @input="tPwd"
      ></mt-field>
    </div>
    <div class="second widthBox">
      <mt-button class="sendPwd" type="primary" @click="nextStep">保存</mt-button>
    </div>
  </div>
</template>

<script>
import { Toast } from "mint-ui";
import heade from "../header/return";

export default {
  name: "forget",
  components: {
    heade: heade
  },
  data() {
    return {
      toastInstanse: null,
      checkNo: true,
      phone: "",
      captch: "",
      phoneState: "",
      passwordCheckState: "",
      send: false,
      restTime: 60,
      captchCode: "123456",
      regCode: '',
      pwd1: '',
      pwd2: '',
      setPwd: ''
    }
  },
  methods: {
    checkPhone() {
      var phone = this.$data.phone;
      document
        .getElementsByClassName("mint-cell-value")[0]
        .getElementsByTagName("input")[0]
        .setAttribute("maxlength", "11");
      if (!/^1(3|4|5|6|7|8|9)\d{9}$/.test(phone)) {
        this.$data.send = false;
        this.$data.phoneState = "error";
      } else {
        this.$data.send = true;
        this.$data.phoneState = "success";
      }
      if (this.$data.phoneState == "error") {
        this.$data.checkNo = true;
      } else if (
        this.$data.phoneState == "success" &&
        this.$data.restTime == "60"
      ) {
        this.$data.checkNo = false;
      }
    },
    sendCaptcha() {
      this.$axios
        .get("/littleu/user/telexist", {
          params: {
            tel: this.$data.phone
          }
        })
        .then(resp => {
          console.log(resp)
          this.$data.captchCode = resp.data;
          this.$data.regCode = 'true'
        })
      this.$refs.capPrompt.style = "display:block";
      var that = this;
      this.$data.checkNo = true;
      var time = setInterval(function() {
        that.$data.restTime--;
        if (that.$data.restTime == 0) {
          clearInterval(time);
          that.$data.checkNo = false;
          that.$refs.capPrompt.style = "display:none";
          that.$data.restTime = 60;
        }
      }, 1000)
    },
    nextStep () {
      let phone = this.phone
      let pwd2 = this.pwd2
      // console.log(this.captch, this.captchCode)
      if (this.captch == this.captchCode && this.phoneState == "success") {
        if (this.setPwd === 'success') {
          this.$axios.put("/littleu/user/changepwd", {
            tel: phone,
            pwd: pwd2
            }).then((resp) => {
              console.log(resp)
              this.$router.push({ path: '/' })
            });
          // 修改成功跳转
        } else {
          this.setPwd = 'error'
        }
      } else {
        this.$data.toastInstanse = Toast({
          message: "验证码有误",
          position: "middle",
          duration: 3000
        })
      }
    },
    // 确认密码相同
    tPwd () {
      this.setPwd = ''
      if (this.pwd2 === this.pwd1) {
        this.setPwd = 'success'
      } else {
        this.setPwd = ''
      }
    }
    // 更改密码
    // sure () {
    //   if (this.$data.value19 != this.$data.value20) {
    //     this.$Message.error("密码确认错误");
    //     console.log("密码确认错误");
    //   } else if (this.$data.value19 == this.$data.value20) {
    //     $(".mint-msgbox").css("display", "none");
    //     $(".v-modal").css("display", "none");
    //     console.log("密码确认正确");
    //     var oldPwd = this.$data.value18;
    //     var newPwd = this.$data.value20;
    //     // this.$router.go(0)
    //     this.$axios({
    //       method: "put",
    //       url: "/littleu/distribution/changePassword",
    //       headers: {
    //         "Content-type": "application/json;charset=utf-8"
    //       },
    //       data: JSON.stringify({ password: oldPwd, newPassword: newPwd })
    //     }).then(res => {
    //       console.log(res.data);
    //       if (res.data == false) {
    //         this.$Message.error("修改密码失败，原密码输入错误");
    //       } else if (res.data == true) {
    //         this.$Message.success("新密码修改成功");
    //       }
    //     });
    //   }
    // }
  },
  mounted() {
    this.$refs.captcha.$el.style = "width:65%";
    // this.$refs.dateBox.getElementsByTagName("input")[0].setAttribute('class','disType');
  },
  created() {
    var s = "1950-01-01 00:00:00";
    s = s.replace(/-/g, "/");
    var date = new Date(s);
    this.$data.starDate = date;
    var endDate = new Date();
    this.$data.endDate = endDate;
  }
}
</script>

<style scoped>
* {
  text-align: left;
}
.inputBorder {
  border: 1px #c3c3c3 solid;
  border-radius: 4px;
}

.sendCaptcha {
  font-size: 12px;
}

.second {
  margin-top: 4%;
  position: relative;
}
  .prompt {
    font-size: 12px;
    color: grey;
  }

  .sendCaptcha {
    position: absolute;
    right: 5%;
    top: 0;
    height: 48px;
  }

  .registSum {
    margin-top: 3%;
    width: 90%;
    margin-left: 5%;
    text-align: center;
  }

  .userKnow{
    width: 90%;
    height: 360px;
    margin-left: 5%;
    margin-top: 3%;
    border: 1px #e2e2e2 solid;
    padding: 2%;
  }
  .paddingBox{
    padding-left: 5%;
  }
  .widthBox{
    width: 90%;
    margin-left: 5%;
  }
.nextBtn>>>label{
  widows: 100%;
  text-align: center;
}
.sendPwd {
  width: 100%;
  text-align: center
}
</style>
