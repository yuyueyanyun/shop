<template>
  <div class="parti">
    <heade :title="title" url="/distribution/soon">
      <!-- <template slot="user">
        <div @click="address">
          <p>个人</p>
        </div>
      </template> -->
    </heade>
    <div class="state">
      <div class="txt_title">
        <p :v-if="!!sendS">{{sendS}}</p>
        <p>{{sendStatus}}：{{sendTxt}}</p>
      </div>
      <p>收银条台号：{{obj.orderDetailend.moneyNum}}</p>
      <p>流水号：{{obj.orderDetailend.spendNum}}</p>
      <p>时间：{{obj.orderDetailend.ticketDate}}</p>
      <p>审核日期：{{obj.orderDetailend.verifyTime}}</p>
    </div>
    <div class="user">
      <p>收件人：{{obj.orderDetailend.receiver}}</p>
      <p>电话：{{obj.orderDetailend.tel1}}</p>
      <p>备用电话：{{obj.orderDetailend.tel2}}</p>
      <p>收货地址：{{obj.orderDetailend.address}}</p>
    </div>
    <div class="parti_txt">
      <p class="txt_title">订单详情</p>
    </div>
    <div class="minute">
      <p>服装订单</p>
      <table>
        <thead>
          <tr>
            <th>商品分类1</th>
            <th>商品分类2</th>
            <th>数量</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in obj.goodsDetails">
            <td>{{item.goodsName1}}</td>
            <td>{{item.goodsName2}}</td>
            <td>{{item.goodsCount}}</td>
          </tr>
        </tbody>
      </table>
      <p>箱数：{{obj.orderDetailend.sendCount}}</p>
      <p>重量：{{obj.orderDetailend.sendWeight}}kg</p>
      <p>金额：{{obj.orderDetailend.sendprice}}</p>
    </div>
    <!-- <div class="posi" v-if="true">
    <p class="txt_title">当前位置:</p>
    </div>-->
  </div>
</template>

<script>
import heade from "../header/return";
export default {
  name: "parti",
  components: {
    heade: heade
  },
  data: function() {
    //          待配送，配送中，成功，失败(退回中，退回成功)
    // 对应sendStatus：  1 2  3  4(5  6)
    return {
      title: "订单详情",
      obj: {
        orderDetailend: {
          sendStatus: "4",
          moneyNum: "m123456",
          spendNum: "123456",
          ticketDate: null,
          verifyTime: "2019-12-31 05:47:13",
          receiver: "王八羔子",
          tel1: "13696854522",
          tel2: null,
          address: "花果山水帘洞",
          sendCount: null,
          sendWeight: null,
          sendPrice: null,
          sendType: "有害垃圾",
          memos: "配送成功"
        },
        goodsDetails: [
          {
            goodsName1: "日化",
            goodsName2: "日化",
            goodsCount: 15
          },
          {
            goodsName1: "衣物",
            goodsName2: "毛衣",
            goodsCount: 16
          }
        ]
      },
      // 是否退回 已退回
      sendS: "",
      // 配送状态
      sendStatus: "待配送",
      sendTxt: ""
    };
  },
  created() {
    console.log(this.$route.query.id);
    let id = this.$route.query.id;
    this.$axios
      .get("/littleu/user/orderDetailend", {
        params: {
          orderId: id
        },
        headers: { ContentType: "application/json;charset=utf-8" }
      })
      .then(resp => {
        console.log(resp);
        this.obj = resp.data;
        switch (resp.data.orderDetailend.sendStatus) {
          case "1":
            this.sendStatus = "待配送";
            break;
          case "2":
            this.sendStatus = "配送中";
            this.sendTxt = resp.data.orderDetailend.memos;
            break;
          case "3":
            this.sendStatus = "签收成功";
            this.sendTxt = resp.data.orderDetailend.memos;
            break;
          case "4":
            this.sendStatus = "签收失败";
            break;
          case "5":
            this.sendS = "退回中";
            this.sendStatus = "签收失败";
            this.sendTxt = resp.data.orderDetailend.memos;
            break;
          case "6":
            this.sendS = "已退回";
            this.sendStatus = "签收失败";
            this.sendTxt = resp.data.orderDetailend.memos;
            break;
          default:
            break;
        }
      })
      .catch(err => {
        console.log(err);
      });
  }
};
</script>

<style scoped>
.parti > div:not(:first-of-type) {
  padding-left: 10px;
}
p {
  text-align: left;
}
p[class="txt_title"],
.txt_title > p:not(.prom) {
  font-weight: 600;
}
.state {
  background-color: #d7d7d7;
  padding: 5px 0;
  margin-bottom: 10px;
}
.state > div {
  padding-bottom: 5px;
}
.state > div > p {
  font-size: 14px;
  line-height: 20px;
}
.state > p {
  font-size: 12px;
  padding-left: 10px;
}
.user {
  padding-top: 10px;
  padding-bottom: 10px;
  background-color: #f2f2f2;
}
.user > p {
  padding-left: 20px;
  line-height: 24px;
  font-size: 13px;
}
.parti_txt > p {
  font-weight: 600;
  line-height: 24px;
}
.parti > .minute {
  background-color: #f2f2f2;
  padding-left: 0;
  font-size: 12px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.minute > p {
  box-sizing: border-box;
  padding-left: 20px;
  width: 100%;
  line-height: 20px;
}
.minute table {
  margin-top: 10px;
  width: 70%;
  border-collapse: collapse;
}
.minute thead tr {
  background-color: #d7d7d7;
}
.minute thead tr th {
  font-weight: 400;
}
.minute thead tr th,
.minute tr td {
  width: 33%;
  height: 20px;
  border: 1px solid #a9a9a9;
}
.posi {
  padding-top: 10px;
}
</style>
