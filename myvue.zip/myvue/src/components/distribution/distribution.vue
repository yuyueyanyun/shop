<template>
  <div>
    <div class="header">
      <mt-header :title="title">
        <router-link tag='span' to="/userCenter" slot="left">
          <mt-button icon="back">返回</mt-button>
        </router-link>
      </mt-header>
    </div>
    <ul class="nav">
      <router-link to="/distribution/soon" tag="li" active-class="active" @click.native="getData">待配送</router-link>
      <router-link to="/distribution/ing" tag="li" active-class="active" @click.native="getData">配送中</router-link>
      <router-link to="/distribution/success" tag="li" active-class="active" @click.native="getData">签收成功</router-link>
      <router-link to="/distribution/failure" tag="li" active-class="active" @click.native="getData">签收失败</router-link>
    </ul>
    <div  v-for="item in orderData" :key="item.orderId"  @click="lis(item.orderId)" class="parti" :name="item.orderId">
      <div v-if="item.sendStatus === '1'">
        <router-view :num="item.orderId" state="待派单" :shop="item.site" :fun="item.sendType" :shopper="item.receiver" :time="item.verifyTime"></router-view>
      </div>
       <div v-if="item.sendStatus === '2'">
         <div v-if="!item.catchTime">
          <router-view :num="item.orderId" state="配送中" :shop="item.site" :worker="item.userName" :fun="item.sendType" :shopper="item.receiver" sCTime="派单时间" :time="item.sendTime"></router-view>
         </div>
         <div v-else>
          <router-view  :num="item.orderId" state="配送中3" :shop="item.site" :worker="item.userName" :fun="item.sendType" :shopper="item.receiver" sCTime="取货时间" :time="item.catchTime"></router-view>
         </div>
      </div>
       <div v-if="item.sendStatus === '3'">
        <router-view :num="item.orderId" state="签收成功" :shop="item.site" :worker="item.userName" :fun="item.sendType" :shopper="item.receiver" :time="item.completeTime" :mos='item.memos'></router-view>
      </div>
      <div v-if="item.sendStatus === '4' || item.sendStatus === '5' || item.sendStatus === '6'">
        <router-view :num="item.orderId" state="签收失败" :shop="item.site" :worker="item.userName" :fun="item.sendType" :shopper="item.receiverr" :time="item.completeTime" :mos='item.memos' :status='item.sendStatus'></router-view>
      </div>
      <!-- <router-view :num="item.num" :state="item.state" :shop="item.shop" :worker="item.worker" :fun="item.fun" :shopper="item.shopper" :time="item.time"></router-view> -->
    </div>
  </div>
</template>

<script>
export default {
  name: 'distribution',
  data: function () {
    return {
      title: '订单配送中',
      orderData: ''
    }
  },
  created () {
    let page = this.$route.path.split('/')
    let getPage = ''
    switch (page[page.length - 1]) {
      case 'soon':
        getPage = 1
        this.title = '待配送'
        break
      case 'ing':
        getPage = 2
        this.title = '配送中'
        break
      case 'success':
        getPage = 3
        this.title = '签收成功'
        break
      case 'failure':
        getPage = 4
        this.title = '签收失败'
        break
    }
    this.$axios.get('/littleu/user/selectSendOrder' + getPage, {
      headers: {'ContentType': 'application/json;charset=utf-8'}
    }).then(resp => {
      this.orderData = resp.data
    }).catch((err) => {
      console.log(err)
    })
  },
  methods: {
    lis (num) {
      this.$router.push({path: '/parti', query: {id: num}})
    },
    getData () {
    // 获取当前页面的url
      let page = this.$route.path.split('/')
      let getPage = ''
      switch (page[page.length - 1]) {
        case 'soon':
          getPage = 1
          break
        case 'ing':
          getPage = 2
          break
        case 'success':
          getPage = 3
          break
        case 'failure':
          getPage = 4
          break
      }
      // this.$axios.get('/littleu/user/address', {
      //   headers: {'ContentType': 'application/json;charset=utf-8'}
      // }).then(resp => {
      //   // console.log(resp)
      //   console.log(JSON.parse(resp.data))
      // }).catch((err) => {
      //   console.log(err)
      // })
      this.$axios.get('/littleu/user/selectSendOrder' + getPage, {
        headers: {'ContentType': 'application/json;charset=utf-8'}
      }).then(resp => {
        // console.log(resp)
        this.orderData = resp.data
        console.log(this.orderData)
      }).catch((err) => {
        console.log(err)
      })
    }
  }
}
</script>

<style scoped>
.header {
    position: relative;
  }
  header+div{
    position: absolute;
    top: 0;
    right: 10px;
    height: 100%;
    color: #fff;
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
  header+div>p {
    font-size: 14px;
  }
  
  ul, li{
    list-style: none;
  }
  .nav {
    display: flex;
    justify-content: space-around;
    align-items: center;
    height: 48px;
    border-bottom: 2px solid #f3f3f3;
  }
  .nav>li {
    height: 24px;
    line-height: 20px;
    border-bottom: 2px solid #fff;
  }
  .nav>li[class ~="active"] {
    border-bottom: 2px solid #34a5ab;
  }
</style>
