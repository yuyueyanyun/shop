<template>
  <div class="list">
    <div class="list1"><p>订单编号：{{num}}</p> <p>{{state}}</p></div>
    <div class="list2"><p>门店：{{shop}}</p><p>配送员：{{worker}}</p><p>{{fun}}</p></div>
    <div class="list3"><p>收货人：{{shopper}}</p><p>签收时间：{{time}}</p></div>
    <div class="list4"><p>签收情况：{{mos}}</p><p v-if="status === '5'">退回中</p><p v-else-if="status === '6'">已退回</p></div>
  </div>
</template>

<script>
export default {
  name: 'failure',
  props: ['num', 'state', 'shop', 'worker', 'fun', 'shopper', 'time', 'mos', 'status']
}
</script>
<style scoped>
  .list {
    width: 94%;
    padding-left: 4px;
    padding-right: 4px;
    margin: 4px auto 10px;
    border-left: 4px solid #36a3a8;
    border-radius: 4px 0 2px 4px;
    box-shadow: 2px 2px 0 0 #e7e7e7;
  }
  .list>div {
    display: flex;
  }
  .list>.list1 {
    height: 40px;
    line-height: 40px;
    border-bottom: 1px solid #999;
  }
  .list>div p:first-of-type{
    text-align: left;
  }
  .list>.list1 p:first-of-type{
    width: 80%;
  }
  .list>div p:last-of-type{
    text-align: right;
  }
  .list>.list1 p:last-of-type {
    font-size: 12px;
    color: #999999;
  }
  .list>div:not(:first-of-type) {
    height: 30px;
    line-height: 30px;
    font-size: 14px;
    display: flex;
    justify-content: space-between;
  }
  .list>.list2>p:first-of-type {
    width: 40%;
  }
  .list>.list2>p:nth-last-child(2) {
    width: 40%;
  }
  .list>.list2>p:last-of-type {
    width: 20%;
  }
  .list>.list3>p:last-of-type  {
    width: 60%;
    color: #999;
  }
</style>
