<template>
<div class="my-container">
  <heade title="添加收货地址">
    <template slot="save" >
      <div  @click="setAddr"><p>保存</p></div>
    </template>
  </heade>
  <van-cell-group>
    <van-field label="姓名：" label-align="right" placeholder="请填写收货人姓名" v-model.lazy="user.name"  @input="getname" :error-message="regname"/>
  </van-cell-group>
  <van-cell-group>
    <van-field label="手机：" label-align="right" placeholder="请填写收货人手机号" v-model.lazy="user.phone1" @change="getPhone1" @input="delP1" :error-message="regphone1"/>
  </van-cell-group>
  <van-cell-group>
    <van-field label="备用手机：" label-align="right"  placeholder="请填写备用手机号" v-model.lazy="user.phone2" @change="getPhone2" @input="delP2" :error-message="regphone2"/>
  </van-cell-group>
  <!--弹出层-->
  <van-cell is-link @click="show"><span class="city">{{user.position.province}}</span><span class="city">{{user.position.city}}</span><span class="city">{{user.position.county}}</span></van-cell>
  <van-popup v-model="flag" :get-container="getContainer"  position="bottom" :style="{ height: '80%' }">
    <van-area :area-list="areaList"  :value="user.position.value"  :columns-num="3" @confirm="onAddr" @cancel="shut" title="请选择"/>
  </van-popup>
  <van-cell is-link @click="showP"><span class="city"><span>详细位置：</span>{{user.position.xiangxi}}</span></van-cell>
  <van-popup v-model="flagP" :get-container="getContainer"  position="bottom" :style="{ height: '80%' }">
    <!--地图-->
    <!--<emap></emap>-->
    <van-cell-group>
      <van-field v-model="user.selTxt" placeholder="请输入详细地址" @input="getPosi">
        <van-button slot="button" size="small" type="primary" @click="onCheckAdd">确定</van-button>
      </van-field>
    </van-cell-group>
    <div v-for="item in arr" :key="item.name+item.address">
      <van-cell-group>
        <van-field v-model="item.name+item.address" disabled @click="checkAdd(item.name+item.address)"/>
      </van-cell-group>
    </div>
  </van-popup>
</div>
</template>

<script>
import heade from '../header/return'
// import emap from '../map/emap'
import areaList from '../../assets/js/area'
// import { amapManager } from 'vue-amap';
// import { getHomeMultidata } from "../../assets/js/axios2";
export default {
  name: 'newAddr',
  components: {
    heade: heade
    // emap: emap
  },
  data () {
    return {
      // 标记 电话是否正确
      regname: '',
      regphone1: '',
      regphone2: '',
      // 用户信息
      user: {
        name: '',
        phone1: '',
        phone2: '',
        position: {
          value: '110101',
          province: '所在地区',
          city: '',
          county: '',
          xiangxi: ''
        },
        selTxt: ''
      },
      // 控制弹框显示
      flag: false,
      flagP: false,
      areaList: areaList,
      // 输入提示
      arr: ''
    }
  },
  methods: {
    getname: function () {
      this.regname = ''
    },
    getPhone1: function () {
      let phone = this.user.phone1
      // console.log(phone);
      this.regphone1 = regPhone(phone)
      // console.log(this.regphone1)
    },
    getPhone2: function () {
      let phone = this.user.phone2
      this.regphone2 = regPhone(phone)
    },
    delP1: function () {
      this.regphone1 = ''
    },
    delP2: function () {
      this.regphone2 = ''
    },
    getContainer () {
      return document.querySelector('.my-container')
    },
    // 控制弹框方法
    show () {
      console.log(this.areaList)
      this.flag = true
    },
    showP () {
      this.flagP = true
    },
    // 弹框取消
    shut () {
      this.flag = false
    },
    shutP () {
      this.flagP = false
    },
    // 弹框保存
    onAddr (arr) {
      let that = this
      // 确定选择,返回三元素数组
      this.user.position.province = arr[0].name
      this.user.position.city = arr[1].name
      this.user.position.county = arr[2].name
      this.flag = false
    },
    // 输入框变化时调用地图api
    getPosi () {
      getAddsList(this, this.user.selTxt)
    },
    // 选择地址
    checkAdd (str) {
      this.user.selTxt = str
    },
    // 地址保存
    onCheckAdd () {
      this.user.position.xiangxi = this.user.selTxt
      this.flagP = false
    },
    // 保存
    setAddr () {
      let name = this.user.name
      let phone1 = this.user.phone1
      let phone2 = this.user.phone2
      let province = this.user.position.province
      let city = this.user.position.city
      let county = this.user.position.county
      let xiangxi = this.user.position.xiangxi
      if (!phone2) {
        return this.regphone2 = "请输入备用电话号码";
      }
      console.log(name, phone1, phone2, province + ',' + city + ',' + county + ',' + xiangxi)
      if (!!name) {
        if (this.regphone1 === '' && this.regphone2 === '' && !!phone1) {
          this.$axios.post('/littleu/user/receiveAddress', {
            receiver: name,
            tel1: phone1,
            tel2: phone2,
            address: province + ',' + city + ',' + county + ',' + xiangxi
          }).then(resp => {
            console.log(resp)
            this.$router.push({path: '/userAddr'})
          }).catch((err) => {
            console.log(err)
          })
        } else {
          return this.regphone1 = "请输入收货人电话号码";
        }
      } else {
        return this.regname = "请输入收货人姓名";
      }
    }
  },
  watch: {
    // 城市发生变化时调用地图查询pi
    'user.position.city': {
      deep: true,     // 深度监听
      handler: function (newV, oldV) {
        getAddsList(this, this.user.position.city)
      }
      // immediate: true  第一次绑定时就监听
    }
  }
}
function regPhone (phone) {
  // console.log(!(/^1[3456789]\d{9}$/.test(phone)));
  if (!(/^1[3456789]\d{9}$/.test(phone))) {
    return '请输入正确电话号码'
  } else {
    return ''
  }
}
function getAddsList (obj, keywords) {
  obj.$axios.get('https://restapi.amap.com/v3/assistant/inputtips', {
    params: {
      key: '0e6ea15d079a13613c36876e0e0a3c86',
      keywords: keywords,
      city: obj.user.position.city,
      datatype: 'poi'
    }
  }).then((resp) => {
    console.log(1111)
    console.log(resp.data.tips)
    obj.arr = resp.data.tips
  }).catch((err) => {
    console.log(2222)
    console.log(err)
  })
  // var params={
  //     key: '0e6ea15d079a13613c36876e0e0a3c86',
  //     keywords: keywords,
  //     city: obj.user.position.city,
  //     datatype: 'poi'
  //   }
  // getHomeMultidata(params).then(res => {
  //   console.log(res)
  // })
}
</script>

<style scoped>
  .mint-cell {
    margin: 0 10px;
    border-bottom: 1px solid #ccc;
  }
  input {
    font-size: 10px;
  }
  input::placeholder {
    font-size: 10px;
    color: #7e7d81;
  }
  .mint-cell-value {
    margin-bottom: -10px;
  }
  .city {
    display: inline-block;
    font-size: 14px;
    padding-right: 10px;
    color: #757575;
  }
  .city:first-of-type {
    margin-left:20px;
  }
  .van-cell--clickable {
    padding-left: 10px;
    padding-right: 10px;
  }
</style>
