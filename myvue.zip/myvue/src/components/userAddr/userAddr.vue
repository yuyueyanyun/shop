<template>
  <div>
    <heade title="我的收货地址">
      <template slot="menu">
        <div @click="address">
          <p>添加新地址</p>
        </div>
      </template>
    </heade>
    <div class="lists">
      <ul>
        <li v-for="item in arrD" :key="item.addressId">
          <div v-if="item.default === '1'">
            <div class="radio"  @change="setFirst(item.addressId ,item.address)">
              <input name="default" type="radio" :id="item.addressId" checked />
              <label :for="item.addressId"></label>
            </div>
            <div class="list">
              <div>
                <p>
                  {{item.receiver}}
                  <span>{{item.tel1}}</span>
                </p>
              </div>
              <div>
                <p>{{item.address}}</p>
              </div>
            </div>
            <div class="setAdd" @click="setAddr(item)">
              <p>编辑</p>
            </div>
          </div>
          <div v-else>
            <div class="radio"  @change="setFirst(item.addressId, item.address)">
              <input name="default" type="radio" :id="item.addressId"/>
              <label :for="item.addressId"></label>
            </div>
            <div class="list">
              <div>
                <p>
                   {{item.receiver}}
                  <span>{{item.tel1}}</span>
                </p>
              </div>
              <div>
                <p>{{item.address}}</p>
              </div>
            </div>
            <div class="setAdd" @click="setAddr(item)">
              <p>编辑</p>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import heade from '../header/return'
export default {
  name: 'userAddr',
  components: {
    heade: heade
  },
  data: function () {
    return {
      // default = '1'排第一位
      // arrData: [
      //   {
      //     id: "1",
      //     default: "0",
      //     name: "程晓ss",
      //     phone1: "12345678911",
      //     phone2: "12345678911",
      //     add: "成都市双流区东升镇航都大街好小区蜀道难山大啊但是"
      //   },
      //   {
      //     id: "2",
      //     default: '1',
      //     name: '程晓sss',
      //     phone1: '12345678911',
      //     phone2: '12345678911',
      //     add: '成都市双流区东升镇航都大街好小区'
      //   },
      //   {
      //     id: '3',
      //     default: '0',
      //     name: '程晓ssss',
      //     phone1: '12345678911',
      //     phone2: '12345678911',
      //     add: '成都市双流区东升镇航都大街好小区'
      //   }
      // ],
      arrD: []
    }
  },
  created () {
    this.$axios.get('/littleu/user/address', {
    }).then(resp => {
      console.log(resp)
      let objD = resp.data
      for (let j in objD) {
        if (!!objD[j]) {
          console.log(objD[j])
          this.arrD.push(objD[j])
          console.log(this.arrD)
        }
      }
      console.log(this.arrD)
      // this.arrD = resp.data
      for (let i in this.arrD) {
        if (i == 0) {
          this.arrD[i].default = '1'
        } else {
          this.arrD[i].default = '0'
        }
        this.arrD[i].addressAdd = resp.data[i].address.split(',')
        console.log(this.arrD)
      }
    }).catch((err) => {
      console.log(11111)
      console.log(err)
    })
  },
  // 监控数组变化 区别watch单个变量或整个对象
  // computed: {
  //   sortArr: function () {
  //     return sortArrData(this.arrData, 'default')
  //   }
  // },
  methods: {
    // 设置默认地址
    setFirst (id, address) {
      let add = address
      let arr = this.arrD
      for (let i in arr) {
        if (arr[i].addressId === id) {
          arr[i].default = '1'
        } else {
          arr[i].default = '0'
        }
      }
      console.log(arr)
      this.$axios({
        method: 'put',
        url: '/littleu/user/defaultAddress',
        headers: {
          'Content-type': 'application/json;charset=utf-8'
        },
        data: {address: add}
      }).then((res) => {
        console.log(res)
      })
    },
    // 编辑地址
    setAddr (id) {
      this.$router.push({ path: './altAddr', query: { id: id } })
    },
    // 添加新地址
    address () {
      this.$router.push({ path: './newAddr' })
    }
  }
}
// // 排序
// function sortArrData (arr, key) {
//   return arr.sort(function (a, b) {
//     var x = a[key]
//     var y = b[key]
//     return x > y ? -1 : x < y ? 1 : 0
//   })
// }
</script>

<style scoped>
.radio {
  position: relative;
  line-height: 30px;
}
input[type="radio"] {
  width: 20px;
  height: 20px;
  opacity: 0;
}
label {
  position: absolute;
  left: 5px;
  top: 8px;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  border: 1px solid #999;
}
input:checked + label {
  background-color: #006eb2;
  border: 1px solid #006eb2;
}
input:checked + label::after {
  position: absolute;
  content: "";
  width: 5px;
  height: 10px;
  top: 3px;
  left: 6px;
  border: 2px solid #fff;
  border-top: none;
  border-left: none;
  transform: rotate(45deg);
}

.lists li > div {
  display: flex;
  padding: 10px 0;
}
.lists p {
  text-align: left;
}
.lists li .radio {
  width: 10%;
}
.lists li .list {
  width: 70%;
}
.lists li .list > div:first-of-type p {
  font-size: 16px;
  font-weight: 500;
  line-height: 27px;
}
.lists li .list > div:first-of-type p span {
  display: inline-block;
  padding-left: 10px;
  font-size: 12px;
  font-weight: 400;
  color: #c0c0c0;
}
.lists li .list > div:last-of-type p {
  font-size: 12px;
}
.lists li .setAdd {
  width: 20%;
  display: flex;
  justify-content: center;
  align-items: center;
  color: #999;
}
</style>
